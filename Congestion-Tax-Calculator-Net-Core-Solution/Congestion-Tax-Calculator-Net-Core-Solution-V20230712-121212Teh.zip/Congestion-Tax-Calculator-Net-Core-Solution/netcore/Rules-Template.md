| City       | Start Time | End Time | Amount |
| ---------- | ---------- | -------- | :----: |
| Gothenburg | 06:00      | 06:29    | SEK 8  |
| Gothenburg | 06:30      | 06:59    | SEK 13 |
| Gothenburg | 07:00      | 07:59    | SEK 18 |
| Gothenburg | 08:00      | 08:29    | SEK 13 |
| Gothenburg | 08:30      | 14:59    | SEK 8  |
| Gothenburg | 15:00      | 15:29    | SEK 13 |
| Gothenburg | 15:30      | 16:59    | SEK 18 |
| Gothenburg | 17:00      | 17:59    | SEK 13 |
| Gothenburg | 18:00      | 18:29    | SEK 8  |
| Gothenburg | 18:30      | 05:59    | SEK 0  |
| Stockholm  | 06:00      | 06:59    | SEK 3  |
| Stockholm  | 07:00      | 07:59    | SEK 20 |
| Stockholm  | 08:00      | 08:29    | SEK 15 |
| Stockholm  | 08:30      | 14:59    | SEK 5  |
| Stockholm  | 15:00      | 15:29    | SEK 15 |
| Stockholm  | 15:30      | 16:59    | SEK 20 |
| Stockholm  | 17:00      | 17:59    | SEK 10 |
| Stockholm  | 18:00      | 18:29    | SEK 5  |
| Stockholm  | 18:30      | 05:59    | SEK 0  |