using System;

namespace congestion.calculator
{
    public class Car : IVehicle
    {
        /*
         * TODO: Code Review 04: (Maybe Need Code Refactoring based on CR03): if we decide to change the return value by class name as mentioned for Motorbike, 
         * we should update this code too, or use default concrete implementation for GetVehicleType method of IVehicle interface 
         * as this feature is introduced in C# 8.0. 
         */
        public String GetVehicleType()
        {
            return "Car";
        }
    }
}