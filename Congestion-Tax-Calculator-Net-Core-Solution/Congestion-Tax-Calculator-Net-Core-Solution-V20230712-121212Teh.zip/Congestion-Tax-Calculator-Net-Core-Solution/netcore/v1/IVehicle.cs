using System;

namespace congestion.calculator
{
    /*
     * TODO: Code Review 01: [Need Team Agreement] I re-factor the interface name from 'Vehicle' to 'IVehicle', 
     * because it was not consistent with C# naming convention
     * 
     * Sorry, as you mentioned we don't consider this repository, but it seems there are some useful comments and I checked it a little!
     * Repo: https://github.com/volvo-cars/congestion-tax-calculator
     * The current suggestion is mentioned in this issue of the repo, too: 
     * https://github.com/volvo-cars/congestion-tax-calculator/pull/1#issue-871813181
     */
    public interface IVehicle
    {
        /*
         * TODO: Code Review 02: [Need Team Agreement] I can't understand why software designer decide to return String as output 
         * when there is an Enum for VehicleTypes unless it's for modifiability and flexibility to use new classes that are not 
         * implemented by us, which in that case I think the design pattern of CongestionTaxCalculator should be changed. 
         * New comment: Now that I read entire code, I think it is good and we can skip this comment, 
         * even though `string` can be replaced by `int` other data types, too.
         * 
         * But if the vehicle types are fixed, I prefer to use the defined Enum in CongestionTaxCalculator to avoid String comparison 
         * operator and its challenges.
         */
        String GetVehicleType();
    }
}