namespace congestion.calculator
{
    // TODO: Code Review 38: [Need Team Agreement] Why the name of this class is Motorbike?!
    // The specification said the `Motorcycles` are free of tax. If you really defined this one as a negative test case,
    // it is OK (which I don't think it can be true because the `Car` class is enough for negative test case and we have no other
    // positive test case), otherwise it is another bug that I found when I was generating test cases using ChatGPT
    // based on white box testing approach for `VehicleTollFeeStrategyV2` class and find an unknown class for `Motorcycles` in generated code.
    // (I have no license for automatic test case generation tools and IntelliTest of Visual Studio doesn't support 
    // .net core projects yet. I have to use my free ChatGPT account and it doesn't support long question,
    // but I know how to use it.)
    public class Motorbike : IVehicle
    {
        public string GetVehicleType()
        {
            /*
             * TODO: Code Review 03: [Need Team Agreement] The class name can be replaced by the following code to be compatible with class name change 
             * (if it is required and needed)
             * 
             * Suggested re-factor code: return GetType().Name;
             * 
             * Besides, I prefer to have a convention for this method result to avoid using insensitive comparison and improve the runtime performance.
             * For example we can have an Agreement to use lower case for this result as the below code.
             * 
             * Suggested re-factor code: return GetType().Name.ToLower();
             */
            return "Motorbike";
        }
    }
}