using System;
using System.Diagnostics.CodeAnalysis;

// TODO: Code Review 05: [Need Team Agreement] I add namespace for this class as other classes
namespace congestion.calculator
{
    /*
     * TODO: Code Review 06: [Need Team Agreement] This class is an anti design pattern example for 
     * scalability, modifiability and expandability of vehicles, but a semi-good example for single responsibility principle (SRP)!
     * If we want to add another vehicle, we have to modify this class code and add the rule of the new vehicle, that it is bad!
     * But, as the toll calculation is centralized in this class, if we have any new rule for toll calculation, 
     * we can add the rule just in this class and avoid change propagation in every vehicle class versus template method design pattern.
     * I don't know the requirement of this project exactly and I have to discuss with other stakeholder for a better solution and architecture,
     * but some parts like IsTollFreeVehicle seems to can be changed and use template method design pattern instead of using SRP in this class.
     * In that case we can have the following example code:
     * 
     * <code>
     * interface IVehicle
     * {
     *      String GetVehicleType();
     *      bool IsTollFreeVehicle { get; }
     * }
     * </code>
     * 
     * public class Car : IVehicle
     * {
     *      public String GetVehicleType()
     *      {
     *          return "Car";
     *      }
     *      public bool IsTollFreeVehicle
     *      {
     *          get
     *          {
     *              return true;
     *          }
     *      }
     * }
     * But, if the tollFree consideration should be checked centralized, the current design pattern is OK for it.
     * 
     * -------------------------------------------------------
     * 
     * TODO: Code Review 07: [Need Team Agreement] If we want to improve the modifiability and keep the SRP, 
     * I suggest to use the strategy design pattern and add the following interface for toll fee calculation responsibility:
     * 
     * public interface ITollFeeCalculator
     * {
     *      public int GetTollFee(IVehicle vehicle, DateTime date);
     * }
     * 
     * and the current CongestionTaxCalculator class implement the above interface that if the strategy of tax calculation changed,
     * we don't have to modify the current class and can add a new class with the updated strategy.
     * 
     * Besides, the CongestionTaxCalculator have two concerns:
     *      a) Is the vehicle toll free?
     *      b) Is the date toll free?
     *      
     * We can use the strategy design pattern for both concern to add modifiability to these concerns.
     * For example, the following interface can be used for toll free vehicle checking:
     * 
     * public interface IVehicleTollFeeStrategy
     * {
     *     bool IsVehicleTollFree(IVehicle vehicle); 
     *     // this method can be better for compatibility instead of the above method (IsVehicleTollFree):
     *     // int GetVehicleTollFee(IVehicle vehicle);
     * }
     * 
     * This interface just check the toll free concern but for dates we have to concern:
     *      a) Is the date toll free?
     *      b) If the date is not free, how much is the toll fee of the date?
     * Both concerns can be supported in a simple interface:
     * 
     * public interface IDateTollFeeStrategy
     * {
     *     int GetDateTollFee(DateTime date);
     * }
     * 
     * and the concrete class of toll fee calculation for the date, can have the following signature 
     * using template (ITollFeeCalculator) and dependency injection (IVehicleTollFeeStrategy and IDateTollFeeStrategy) design patterns:
     * 
     * public class TollFeeStrategyV1 : ITollFeeCalculator
     * {
     *      IVehicleTollFeeStrategy vehicleTollFeeStrategy;
     *      IDateTollFeeStrategy dateTollFeeStrategy;
     *      
     *      public TollFeeStrategyV1(IVehicleTollFeeStrategy VehicleTollFeeStrategy, IDateTollFeeStrategy DateTollFeeStrategy)
     *      {
     *          this.vehicleTollFeeStrategy = VehicleTollFeeStrategy;
     *          this.dateTollFeeStrategy = DateTollFeeStrategy;
     *      }
     *      
     *      public int GetTollFee(IVehicle vehicle, DateTime date) { ... }
     * }
     * 
     * Now a VehicleTollFeeStrategy can be implemented and pass to TollFeeStrategyV1 class as the following code:
     * 
     * public class VehicleTollFeeStrategyV1 : IVehicleTollFeeStrategy
     * {
     *      public bool IsVehicleTollFree(IVehicle vehicle) 
     *      { 
     *          // the current code (or final code after revision) of the IsTollFreeVehicle method form 
     *          // current CongestionTaxCalculator class
     *      }
     *      
     *      private enum TollFreeVehicles
     *      {
     *          // the current value of TollFreeVehicles enum from the current CongestionTaxCalculator class
     *      }
     * }
     * 
     * and a DateTollFeeStrategy can be implemented and pass to TollFeeStrategyV1 class as the following code:
     * 
     * public class DateTollFeeStrategyV1 : IDateTollFeeStrategy
     * {
     *      public int GetDateTollFee(DateTime date)
     *      { 
     *          // the current code (or final code after revision) of the GetTollFee method form the current CongestionTaxCalculator class
     *          // without the Vehicle parameter and related codes (not lines!) because the date strategy seems to be independent from vehicle 
     *          // (at least with my current knowledge from the codes)
     *          // in other words, the first line should be as the following:
     *          if (IsTollFreeDate(date)) return 0;
     *          // ... (the remind codes of GetTollFee method
     *      }
     *      
     *      private bool IsTollFreeDate(DateTime date)
     *      {
     *          // the current code (or final code after revision) of IsTollFreeDate method in the CongestionTaxCalculator
     *      }
     * }
     * 
     * Now, maybe there is a question that where should be transfered the removed code of GetTollFee of CongestionTaxCalculator class?
     * those should be transfered to GetTollFee method of TollFeeStrategyV1 as the following:
     * 
     *      public int GetTollFee(IVehicle vehicle, DateTime date) 
     *      { 
     *          if (vehicleTollFeeStrategy.IsVehicleTollFree(vehicle)) return 0;
     *          return dateTollFeeStrategy.GetDateTollFee(date);
     *      }
     * 
     * Now that all toll fee controls are done with SOLID principles, we can do the SOLID on the CongestionTaxCalculator, too,
     * or maybe implement it simply as the following using the dependency injection design pattern:
     * 
     * public class CongestionTaxCalculator
     * {
     *      ITollFeeCalculator tollFeeCalculator;
     *      
     *      public CongestionTaxCalculator(ITollFeeCalculator TollFeeCalculator)
     *      {
     *          this.tollFeeCalculator = TollFeeCalculator;
     *      }
     *      
     *      public int GetTax(IVehicle vehicle, DateTime[] dates)
     *      {
     *          // the current code of GetTax that should replace GetTollFee with tollFeeCalculator.GetTollFee.
     *          // and the order of parameters of GetTollFee should be reversed (based on my new signature of GetTollFee method)
     *      }
     * }
     * 
     * If we want to add modifiability to CongestionTaxCalculator, a template design patter can be used for it too,
     * using the following interface:
     * 
     * public interface ICongestionTaxCalculator
     * {
     *      public int GetTax(IVehicle vehicle, DateTime[] dates);
     * }
     * 
     * and change the first line of CongestionTaxCalculator as the following:
     * 
     * public class CongestionTaxCalculatorV1: ICongestionTaxCalculator
     * 
     * and the constructor should be as the following:
     * 
     * public CongestionTaxCalculatorV1(ITollFeeCalculator TollFeeCalculator)
     * 
     * I did not intentionally change the main code, because we are not using the git now and I want to team can compare both codes,
     * and after their Agreement, we use the final approved code.
     * -------------------------------------------------------
     * 
     * Code Review 8: [Need Team Agreement] If we don't want to use the CD7, This class has no property or field and 
     * the class and its methods can be defined static to avoid developers from instancing dummy object for using this class methods.
     * 
     * Even though if use the CR07, we can use Singleton design pattern to help end-users of the code to avoid instancing as the following:
     * 
     * public static class CongestionTaxCalculator
     * {
     *      private static ICongestionTaxCalculator ctcv1 = 
     *      new CongestionTaxCalculatorV1(
     *          new TollFeeStrategyV1(
     *              new VehicleTollFeeStrategyV1(), 
     *              new DateTollFeeStrategyV1())
     *          );
     *      
     *      public static int GetTax(IVehicle vehicle, DateTime[] dates)
     *      {
     *          return ctcv1.GetTax(vehicle, dates);
     *      }
     * }
     * Now the end-users can use the code easily as the following:
     * CongestionTaxCalculator.GetTax(vehicle, dates);
     * 
     * The final code is implemented in the v2 folder (for better comparison simultaneously as we are not using git).
     * 
     * Besides, I exclude this class from code coverage and changed it to an abstract class to nobody can instantiate it.
     */
    [ExcludeFromCodeCoverage]
    public abstract class CongestionTaxCalculator
    {
        /**
         * Calculate the total toll fee for one day
         *
         * @param vehicle - the vehicle
         * @param dates   - date and time of all passes on one day
         * @return - the total congestion tax for that day
         */
        public int GetTax(IVehicle vehicle, DateTime[] dates)
        {

            DateTime intervalStart = dates[0];
            int totalFee = 0;
            foreach (DateTime date in dates)
            {
                int nextFee = GetTollFee(date, vehicle);
                int tempFee = GetTollFee(intervalStart, vehicle);

                long diffInMillies = date.Millisecond - intervalStart.Millisecond;
                long minutes = diffInMillies / 1000 / 60;

                if (minutes <= 60)
                {
                    if (totalFee > 0) totalFee -= tempFee;
                    if (nextFee >= tempFee) tempFee = nextFee;
                    totalFee += tempFee;
                }
                else
                {
                    totalFee += nextFee;
                }
            }
            if (totalFee > 60) totalFee = 60;
            return totalFee;
        }

        private bool IsTollFreeVehicle(IVehicle vehicle)
        {
            if (vehicle == null) return false;
            String vehicleType = vehicle.GetVehicleType();
            // TODO: Code Review 11: this implementation is not compatible with modifiability of TollFreeVehicles names and values.
            // If somebody add another vehicle to TollFreeVehicles, we have to change this method, otherwise we will have a bug!
            // I implement a new version in CR12 in the IsVehicleTollFree method of VehicleTollFeeStrategyV1 class of CongestionTaxCalculatorNew.cs file
            return vehicleType.Equals(TollFreeVehicles.Motorcycle.ToString()) ||
                   vehicleType.Equals(TollFreeVehicles.Tractor.ToString()) ||
                   vehicleType.Equals(TollFreeVehicles.Emergency.ToString()) ||
                   vehicleType.Equals(TollFreeVehicles.Diplomat.ToString()) ||
                   vehicleType.Equals(TollFreeVehicles.Foreign.ToString()) ||
                   vehicleType.Equals(TollFreeVehicles.Military.ToString());
        }

        public int GetTollFee(DateTime date, IVehicle vehicle)
        {
            if (IsTollFreeDate(date) || IsTollFreeVehicle(vehicle)) return 0;

            int hour = date.Hour;
            int minute = date.Minute;

            if (hour == 6 && minute >= 0 && minute <= 29) return 8;
            else if (hour == 6 && minute >= 30 && minute <= 59) return 13;
            else if (hour == 7 && minute >= 0 && minute <= 59) return 18;
            else if (hour == 8 && minute >= 0 && minute <= 29) return 13;
            // TODO: Code Review 18: This code is not compatible with the specification! 
            // For example, if the date be equal to '14:20' or '2013-03-26 14:25:00' (as is mentioned in the previous of the last sample
            // of the specification), this code doesn't match the mentioned time and skip it
            // but, it should accept and return the 8 value!
            // I modify it in CR19
            else if (hour >= 8 && hour <= 14 && minute >= 30 && minute <= 59) return 8;
            else if (hour == 15 && minute >= 0 && minute <= 29) return 13;
            // TODO: Code Review 21: This code is also wrong based on the specification for | 15:30�16:59 | SEK 18 | 
            // that the minute of hour 15 should be higher than 29 but it accept all the minute higher than 0
            // which is checked by the previous if and even though it will never be run to make a bug now,
            // but if the order of IF statements changed, it maybe cause a bug!
            // I modify it in CR22
            else if (hour == 15 && minute >= 0 || hour == 16 && minute <= 59) return 18;
            else if (hour == 17 && minute >= 0 && minute <= 59) return 13;
            else if (hour == 18 && minute >= 0 && minute <= 29) return 8;
            else return 0; // TODO: Code Review 14: this "else" (not "return") is unnecessary and I removed in new code
        }

        private Boolean IsTollFreeDate(DateTime date)
        {
            int year = date.Year;
            int month = date.Month;
            int day = date.Day;

            if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday) return true;

            if (year == 2013)
            {
                if (month == 1 && day == 1 ||
                    month == 3 && (day == 28 || day == 29) ||
                    month == 4 && (day == 1 || day == 30) ||
                    month == 5 && (day == 1 || day == 8 || day == 9) ||
                    month == 6 && (day == 5 || day == 6 || day == 21) ||
                    month == 7 ||
                    month == 11 && day == 1 ||
                    month == 12 && (day == 24 || day == 25 || day == 26 || day == 31))
                {
                    return true;
                }
            }
            return false;
        }

        private enum TollFreeVehicles
        {
            Motorcycle = 0,
            Tractor = 1,
            Emergency = 2,
            Diplomat = 3,
            Foreign = 4,
            Military = 5
        }
    }
}
