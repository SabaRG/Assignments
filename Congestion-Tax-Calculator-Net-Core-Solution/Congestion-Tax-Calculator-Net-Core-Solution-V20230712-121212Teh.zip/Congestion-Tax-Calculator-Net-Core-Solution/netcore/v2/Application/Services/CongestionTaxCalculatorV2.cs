﻿using congestion.calculator.v2.Application.Services.Interfaces;
using System;
using System.Linq;

namespace congestion.calculator.v2.Application.Services
{
    /// <summary>
    /// This is the main class for CongestionTaxCalculator of a vehicle in several days
    /// This new version added `The single charge rule`
    /// </summary>
    public class CongestionTaxCalculatorV2 : ICongestionTaxCalculatorStrategy
    {
        ITollFeeCalculatorStrategy tollFeeCalculator;

        public CongestionTaxCalculatorV2(ITollFeeCalculatorStrategy TollFeeCalculator)
        {
            tollFeeCalculator = TollFeeCalculator;
        }

        // TODO: Code Review 17: [Need Team Agreement] I suggest to use uint instead of int for the return value to avoid wrong answers strongly
        // TODO: Code Review 37: [Need Team Agreement] I rewrite this code based on CR35 and CR36, but I'm not sure that have a right understanding for the requirement. It should be checked with stakeholders.
        // TODO: Code Review 40: [Need Team Agreement] The `single charge rule` has a vague and exceptional case for end of day! If somebody exit a station at 23:50 and returned at 00:10, now it should pay once or twice?
        //  If once, that pay belong to first day or the next one to be considered for maximum tax limitation rule?
        /// <summary>
        /// This method calculate total tax for a vehicle in several days and overall rules for different days
        /// like 'The single charge rule' is implemented in this code. As this rule is a little general and vague,
        /// in this version of `CongestionTaxCalculatorV2` in the first step all the date_times of every day based on
        /// their [year,month,day] value will be grouped and then dates of a day will be ordered.
        /// For every day, every date_time will be checked with all next ordered date_times and those which have less span 
        /// than 60 minutes will be checked for maximum toll fee and the final value for this span will be the maximum value.
        /// Then all of date_times in this span will be skipped, and this behavior will be repeated for next date_times after 
        /// the span. The span maybe have just 1 date_time if there is no other date_time in its next 60 minutes, or maybe its 
        /// length be 2...N, and then this N dates will be skipped for the next round.
        /// Then, the final maximum toll fee for all 60 minutes spans will be summed and the minimum of total sum of this day 
        /// and 60 -as the maximum toll fee in a day- will be considered for today. Then all toll fee of various days will be
        /// summed and the total fee will be returned.
        /// </summary>
        /// <param name="vehicle"></param>
        /// <param name="dates"></param>
        /// <returns></returns>
        public int GetTax(IVehicle vehicle, DateTime[] dates)
        {
            var datesAndFeeOfDays = dates
                    .Select(d => new
                    {
                        date = d,
                        fee = tollFeeCalculator.GetTollFee(vehicle, d)
                    })
                    .GroupBy(d => new DateTime(d.date.Year, d.date.Month, d.date.Day)); // I delete hour, minute and second to group just dates of a single day
            int totalFee = 0;
            foreach (var datesAndFeeOfADay in datesAndFeeOfDays)
            {
                int totalFeeOfDay = 0;
                var datesFee = datesAndFeeOfADay.OrderBy(d => d.date).ToArray();
                for (int i = 0,j; i < datesFee.Length;)
                {
                    int finalFee = datesFee[i].fee;
                    for (j = i + 1; j < datesFee.Length; j++)
                        if (Math.Abs((datesFee[i].date - datesFee[j].date).TotalMinutes) <= 60)
                            finalFee = Math.Max(finalFee, datesFee[j].fee);
                        else
                        {
                            i = j;
                            break;
                        }
                    totalFeeOfDay += finalFee;
                    if (j == i + 1 && j >= datesFee.Length)
                        break;
                }
                totalFee += Math.Min(60, totalFeeOfDay);
            }
            return totalFee;
        }
    }
}
