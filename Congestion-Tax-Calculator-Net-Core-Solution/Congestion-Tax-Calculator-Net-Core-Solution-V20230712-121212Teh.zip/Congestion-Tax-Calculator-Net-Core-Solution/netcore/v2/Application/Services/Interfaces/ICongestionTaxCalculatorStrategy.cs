﻿using System;

namespace congestion.calculator.v2.Application.Services.Interfaces
{
    /// <summary>
    /// This interface let we implement the strategy design pattern for different congestion tax calculators
    /// </summary>
    public interface ICongestionTaxCalculatorStrategy
    {
        // TODO: Code Review 16: [Need Team Agreement] I suggest to use uint instead of int for the return value
        // to avoid wrong answers strongly
        /// <summary>
        /// Every Congestion Tax Calculator should implement this method to calculate and return the tax for 
        /// a vehicle in different days.
        /// This method calculate total tax for a vehicle in several days and overall rules for different days
        /// like 'The single charge rule' can be implemented in this part.
        /// </summary>
        /// <param name="vehicle"></param>
        /// <param name="dates"></param>
        /// <returns>the tax value between 0 to int.MaxValue</returns>
        int GetTax(IVehicle vehicle, DateTime[] dates);
    }

}
