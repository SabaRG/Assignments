﻿using System;

namespace congestion.calculator.v2.Application.Services.Interfaces
{
    /// <summary>
    /// This interface is used to implement strategy design pattern for toll fee calculation
    /// </summary>
    public interface ITollFeeCalculatorStrategy
    {
        // TODO: Code Review 08: [Need Team Agreement] I suggest to use uint instead of int for the return value
        // to avoid wrong answers strongly
        /// <summary>
        /// Every toll fee calculator should implement this method to return the toll fee based on their strategy
        /// </summary>
        /// <param name="vehicle">this is the vehicle that its toll fee should be calculated</param>
        /// <param name="date">this is the day of toll fee calculation</param>
        /// <returns>the return value can be between 0 to int.MaxValue as the toll fee value</returns>
        int GetTollFee(IVehicle vehicle, DateTime date);
    }

    // CongestionTaxCalculator.GetTax(vehicle, dates);
}
