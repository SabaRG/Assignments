namespace congestion.calculator.v2.Application.Services.Interfaces
{
    /*
     * TODO: Code Review 28: Modified interface based on CR03 that its name should be changed to IVehicle and the formal IVehicle should be removed.
     */
    /// <summary>
    /// This interface let us 
    /// </summary>
    public interface IVehicleV2
    {
        public string GetVehicleType()
#if NETCOREAPP3_1_OR_GREATER
        {
            return GetType().Name;
        }
#else
        ;
#endif
    }
}