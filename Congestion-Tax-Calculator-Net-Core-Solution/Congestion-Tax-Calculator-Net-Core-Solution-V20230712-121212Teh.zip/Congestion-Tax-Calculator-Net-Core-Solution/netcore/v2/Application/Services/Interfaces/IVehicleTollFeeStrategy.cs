﻿namespace congestion.calculator.v2.Application.Services.Interfaces
{
    /// <summary>
    /// In our current toll fee calculator, the vehicle can be free of toll.
    /// This interface is used to implement strategy design pattern for various vehicles toll fee calculation.
    /// </summary>
    public interface IVehicleTollFeeStrategy
    {
        /// <summary>
        /// Every toll fee strategy should implement this method to return that is the vehicle fee of toll or not?
        /// </summary>
        /// <param name="vehicle">the vehicle to be checked for toll fee calculation</param>
        /// <returns>true if the vehicle is free of toll fee, otherwise false</returns>
        bool IsVehicleTollFree(IVehicle vehicle);

        // TODO: Code Review 09: [Need Team Agreement] this method can be better for compatibility instead of
        // the above method (IsVehicleTollFree):
        // int GetVehicleTollFee(IVehicle vehicle);
    }

    // CongestionTaxCalculator.GetTax(vehicle, dates);
}
