﻿using System;

namespace congestion.calculator.v2.Application.Services.Interfaces
{
    /// <summary>
    /// This interface let the toll fee calculator to have different strategy for dates.
    /// </summary>
    public interface IDateTollFeeStrategy
    {
        // TODO: Code Review 10: [Need Team Agreement] I suggest to use uint instead of int for the return value
        // to avoid wrong answers strongly
        /// <summary>
        /// Every toll fee strategy should implement this method to return the toll fee of the received date.
        /// </summary>
        /// <param name="date">the input date to be checked for toll fee calculation</param>
        /// <returns>the toll fee value between 0 to int.MaxValue for the input date</returns>
        int GetDateTollFee(DateTime date);
    }

    // CongestionTaxCalculator.GetTax(vehicle, dates);
}
