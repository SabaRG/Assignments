﻿using congestion.calculator.v2.Application.Services.Interfaces;
using System;

namespace congestion.calculator.v2.Application.Services
{
    /// <summary>
    /// This is our first and current strategy for toll fee calculation of every vehicle in every date.
    /// </summary>
    public class TollFeeStrategyV1 : ITollFeeCalculatorStrategy

    {
        IVehicleTollFeeStrategy vehicleTollFeeStrategy;
        IDateTollFeeStrategy dateTollFeeStrategy;

        /// <summary>
        /// Here we use dependency injection strategy to get the toll fee calculation strategy for vehicles and dates
        /// </summary>
        /// <param name="VehicleTollFeeStrategy">the strategy of vehicles for toll fee calculation</param>
        /// <param name="DateTollFeeStrategy">the strategy of dates for toll fee calculation</param>
        public TollFeeStrategyV1(IVehicleTollFeeStrategy VehicleTollFeeStrategy, IDateTollFeeStrategy DateTollFeeStrategy)
        {
            vehicleTollFeeStrategy = VehicleTollFeeStrategy;
            dateTollFeeStrategy = DateTollFeeStrategy;
        }

        /// <summary>
        /// This method calculate the toll fee value for the given vehicle and date.
        /// </summary>
        /// <param name="vehicle">the input vehicle for toll fee calculation</param>
        /// <param name="date">the input date for toll fee calculation</param>
        /// <returns>the calculated toll fee value for the input vehicle and date between 0 to int.MaxValue</returns>
        public int GetTollFee(IVehicle vehicle, DateTime date)
        {
            if (vehicleTollFeeStrategy.IsVehicleTollFree(vehicle)) return 0;
            return dateTollFeeStrategy.GetDateTollFee(date);
        }
    }
}
