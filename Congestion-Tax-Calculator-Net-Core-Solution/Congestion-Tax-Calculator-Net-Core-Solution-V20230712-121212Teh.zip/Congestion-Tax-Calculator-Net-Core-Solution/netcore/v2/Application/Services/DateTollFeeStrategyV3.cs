﻿using congestion.calculator.v2.Application.Services.Interfaces;
using congestion.calculator.v2.Application.Services.Utility;
using congestion.calculator.v2.Domain.ValueObjects;
using congestion.calculator.v2.Infrastructure.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;

namespace congestion.calculator.v2.Application.Services
{
    /// <summary>
    /// The new date toll fee calculation strategy is implemented in this class
    /// which its rule is not fixed and hard coded and it gets the rules from a repository,
    /// besides the holiday calculation is not hard coded too which cause less CC (Cyclomatic complexity).
    /// </summary>
    public class DateTollFeeStrategyV3 : IDateTollFeeStrategy
    {
        private readonly ITaxRuleRepository _taxRuleRepository;

        string City { get; set; }

        /// <summary>
        /// Constructor for DateTollFeeStrategyV3 class
        /// </summary>
        /// <param name="taxRuleRepository">An object of ITaxRuleRepository used to retrieve tax rules</param>
        /// <param name="city">The city used to calculate toll fee</param>
        public DateTollFeeStrategyV3(ITaxRuleRepository taxRuleRepository, string city)
        {
            _taxRuleRepository = taxRuleRepository;
            City = city;
        }

        /// <summary>
        /// Calculates the toll fee based on the input date
        /// </summary>
        /// <param name="date">The date used to calculate the toll fee</param>
        /// <returns>The calculated toll fee for the input date</returns>
        public int GetDateTollFee(DateTime date)
        {
            var time = date.ToTime();
            if (IsTollFreeDate(date)) return 0;
            var rule = _taxRuleRepository
                .GetAllRules(City)
                // TODO: Code Review 42: [Need Team Agreement] I made some utility extension method, now this line can be re-factored
                //.FirstOrDefault(rule =>  rule.StarTime <= date && rule.EndTime <= date); 
                .FirstOrDefault(rule => time.BetweenOrEqualBothSides(rule.StarTime, rule.EndTime));
            if (rule == null)
                throw new InvalidOperationException($"There is no appropriate rule for {date} in {City}");
            return rule.Fee;
        }

        // TODO: Code Review 41: [Need Team Agreement] We can have a more reliable and none hard code version of this method to can be used for every year, not just 2013.
        // As you don't respond, I do it myself to decrease code CC (Cyclomatic Complexity)! Please come on to check it together. :-)
        /// <summary>
        /// This method check a date that is toll free or not.
        /// List of National and Regional Public Holidays of Sweden in 2013:
        /// https://www.calendarlabs.com/holidays/sweden/2013
        /// </summary>
        /// <param name="date">the input date</param>
        /// <returns>true if the given date is toll free, otherwise false</returns>
        private static bool IsTollFreeDate(DateTime date)
        {
            return date.DayOfWeek == DayOfWeek.Saturday // Check if date falls on a weekend
                || date.Month == 7 // Check if date is in July
                                   // Check if date is in the set of toll-free dates
                || SwedishHolidayService.IsHoliday(date.Date, SwedishHolidayService.HolidayType.Public)
                || SwedishHolidayService.IsHoliday(date.AddDays(1).Date, SwedishHolidayService.HolidayType.Public)
                ;
        }
    }
}
