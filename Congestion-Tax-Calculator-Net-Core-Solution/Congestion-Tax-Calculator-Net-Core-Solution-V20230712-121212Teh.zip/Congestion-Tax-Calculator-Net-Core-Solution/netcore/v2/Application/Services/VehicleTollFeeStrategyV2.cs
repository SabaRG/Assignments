﻿using congestion.calculator.v2.Application.Services.Interfaces;
using System;
using System.Linq;

namespace congestion.calculator.v2.Application.Services
{
    /// <summary>
    /// The current vehicle toll fee calculation strategy is implemented in this class
    /// TODO: Code Review 29: This code is built after applying CR12, CR26, CR27, Please remove this line
    /// </summary>    
    public class VehicleTollFeeStrategyV2 : IVehicleTollFeeStrategy
    {
        /// <summary>
        /// This method check a vehicle to be toll free or not.
        /// </summary>
        /// <param name="vehicle">the input vehicle for checking</param>
        /// <returns>true if the input vehicle is free of toll fee, otherwise false</returns>
        public bool IsVehicleTollFree(IVehicle vehicle)
        {
            if (vehicle == null) return false;
            string vehicleType = vehicle.GetVehicleType();
            return Enum.GetNames(typeof(TollFreeVehicles)).Any(name => name.Equals(vehicleType, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// This enum contains the names of current toll free vehicles based on this strategy
        /// Convention: All names should be in Capital case
        /// </summary>
        private enum TollFreeVehicles
        {
            Emergency,
            Bus,
            Diplomat,
            Motorcycle,
            Military,
            Foreign,
        }
    }
}
