﻿using congestion.calculator.v2.Application.Services.Interfaces;
using congestion.calculator.v2.Infrastructure.Providers;
using System;

namespace congestion.calculator.v2.Application.Services
{
    /// <summary>
    /// This class uses Singleton design pattern to avoid user from instancing new dummy object for tax calculation.
    /// </summary>
    public static class MainCongestionTaxCalculatorNew
    {
        private static ICongestionTaxCalculatorStrategy ctcv1 =
            new CongestionTaxCalculatorV1(
                new TollFeeStrategyV1(
                    new VehicleTollFeeStrategyV1(),
                    new DateTollFeeStrategyV1())
                );

        public static int GetTaxV1Base(IVehicle vehicle, DateTime[] dates)
        {
            return ctcv1.GetTax(vehicle, dates);
        }


        private static ICongestionTaxCalculatorStrategy ctcv2 =
            new CongestionTaxCalculatorV2(
                new TollFeeStrategyV1(
                    new VehicleTollFeeStrategyV2(),
                    new DateTollFeeStrategyV2())
                );

        public static int GetTaxV2(IVehicle vehicle, DateTime[] dates)
        {
            return ctcv2.GetTax(vehicle, dates);
        }

        const string CSVFileAddress = "Rules.csv";
        const string MDFileAddress = "Rules.md";

        private static ICongestionTaxCalculatorStrategy ctcv3CSV =
            new CongestionTaxCalculatorV2(
                new TollFeeStrategyV1(
                    new VehicleTollFeeStrategyV2(),
                    new DateTollFeeStrategyV3(
                        new CSVTaxRuleRepository(CSVFileAddress), "Gothenburg"))
                );

        public static int GetTaxV3GothenburgFromCSVFile(IVehicle vehicle, DateTime[] dates)
        {
            return ctcv3CSV.GetTax(vehicle, dates);
        }

        public static int GetTaxV3CSVFile(IVehicle vehicle, DateTime[] dates, string City = "Gothenburg")
        {
            ICongestionTaxCalculatorStrategy ctcv4 =
            new CongestionTaxCalculatorV2(
                new TollFeeStrategyV1(
                    new VehicleTollFeeStrategyV2(),
                    new DateTollFeeStrategyV3(
                        new CSVTaxRuleRepository(CSVFileAddress), City))
                );
            return ctcv4.GetTax(vehicle, dates);
        }

        private static ICongestionTaxCalculatorStrategy ctcv3MD =
            new CongestionTaxCalculatorV2(
                new TollFeeStrategyV1(
                    new VehicleTollFeeStrategyV2(),
                    new DateTollFeeStrategyV3(
                        new MDTaxRuleRepository(MDFileAddress), "Gothenburg"))
                );

        public static int GetTaxV3GothenburgFromMDFile(IVehicle vehicle, DateTime[] dates)
        {
            return ctcv3MD.GetTax(vehicle, dates);
        }

        public static int GetTaxV3MDFile(IVehicle vehicle, DateTime[] dates, string City = "Gothenburg")
        {
            ICongestionTaxCalculatorStrategy ctcv4 =
            new CongestionTaxCalculatorV2(
                new TollFeeStrategyV1(
                    new VehicleTollFeeStrategyV2(),
                    new DateTollFeeStrategyV3(
                        new MDTaxRuleRepository(MDFileAddress), City))
                );
            return ctcv4.GetTax(vehicle, dates);
        }
    }
}
