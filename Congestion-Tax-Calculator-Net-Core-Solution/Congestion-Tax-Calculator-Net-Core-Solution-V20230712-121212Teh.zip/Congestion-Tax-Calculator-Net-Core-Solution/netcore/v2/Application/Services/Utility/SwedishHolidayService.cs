﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Net.WebRequestMethods;

namespace congestion.calculator.v2.Application.Services.Utility
{

    /// <summary>
    /// A class for checking whether a date is a holiday in Sweden or not.
    /// `HolidayChecker`
    /// </summary>
    public class SwedishHolidayService
    {
        /// <summary>
        /// This enum can be used to select which kind of holiday for checking is selected.
        /// For combination of holidays, you can use it e.g., HolidayType.Public | HolidayType.CommonLocal
        /// </summary>
        [Flags]
        public enum HolidayType
        {
            Public = 0x01,
            CommonLocal = 0x02,
            TypicalNonWorking = 0x04
        }

        /// <summary>
        /// Initializes static fields of <see cref="SwedishHolidayService"/> class.
        /// </summary>
        private static DayOfWeek swedishWeeklyHoliday = DayOfWeek.Sunday;

        /// <summary>
        /// This field is for caching current year holidays and improving the runtime performance
        /// </summary>
        private static DateTime[] swedishPublicHolidays = GetSwedishPublicHolidays(DateTime.Now.Year);
        private static DateTime[] swedishCommonLocalHolidays = GetSwedishCommonLocalHolidays(DateTime.Now.Year);
        private static DateTime[] swedishTypicalNonWorkingHolidays = GetSwedishTypicalNonWorkingHolidays(DateTime.Now.Year);


        /// <summary>
        /// Checks whether a date is a holiday in Sweden or not.
        /// </summary>
        /// <param name="inputDate">The date to check.</param>
        /// <returns>True if the input date is a holiday in Sweden, false otherwise.</returns>
        public static bool IsHoliday(DateTime inputDate, HolidayType holidayType)
        {
            if (inputDate.DayOfWeek == swedishWeeklyHoliday)
                return true;
            // Check if the input date is in the Swedish holidays array or the Swedish weekly holiday
            // If the input date is not a holiday in Sweden or the Swedish weekly holiday, it is a working day
            if (inputDate.Year == swedishPublicHolidays[0].Year)
                return (holidayType & HolidayType.Public) > 0 && swedishPublicHolidays.Any(d => d.Date.Equals(inputDate.Date))
                        || (holidayType & HolidayType.CommonLocal) > 0 && swedishCommonLocalHolidays.Any(d => d.Date.Equals(inputDate.Date))
                        || (holidayType & HolidayType.TypicalNonWorking) > 0 && swedishTypicalNonWorkingHolidays.Any(d => d.Date.Equals(inputDate.Date))
                        ;
            // Check it the inputDate is not in current year, get its holiday
            else
                return (holidayType & HolidayType.Public) > 0 && GetSwedishPublicHolidays(inputDate.Year).Any(d => d.Date.Equals(inputDate.Date))
                    || (holidayType & HolidayType.CommonLocal) > 0 && GetSwedishCommonLocalHolidays(inputDate.Year).Any(d => d.Date.Equals(inputDate.Date))
                    || (holidayType & HolidayType.TypicalNonWorking) > 0 && GetSwedishTypicalNonWorkingHolidays(inputDate.Year).Any(d => d.Date.Equals(inputDate.Date))
                    ;
        }

        /// <summary>
        /// Calculates the date of Easter Sunday for a given year using the Gregorian calendar.
        /// </summary>
        /// <param name="year">The year for which to calculate Easter Sunday.</param>
        /// <returns>The date of Easter Sunday for the input year.</returns>
        public static DateTime GetEasterSunday(int year)
        {
            // Calculate the date of Easter Sunday based on the Gregorian calendar
            int a = year % 19;
            int b = year / 100;
            int c = year % 100;
            int d = b / 4;
            int e = b % 4;
            int f = (b + 8) / 25;
            int g = (b - f + 1) / 3;
            int h = (19 * a + b - d - g + 15) % 30;
            int i = c / 4;
            int k = c % 4;
            int l = (32 + 2 * e + 2 * i - h - k) % 7;
            int m = (a + 11 * h + 22 * l) / 451;
            int month = (h + l - 7 * m + 114) / 31;
            int day = (h + l - 7 * m + 114) % 31 + 1;

            return new DateTime(year, month, day);
        }

        /// <summary>
        /// Calculates Midsummer's Eve in the Swedish calendar for a given year.
        /// </summary>
        /// <param name="year">The year for which to calculate Midsummer's Eve.</param>
        /// <returns>The date of Midsummer's Eve in the Swedish calendar for the given year.</returns>
        public static DateTime CalculateMidsummersEve(int year)
        {
            // Create a DateTime object for June 19th of the given year.
            DateTime date = new DateTime(year, 6, 19);
            // Find the first Friday after June 19th.
            date = date.AddDays(DayOfWeek.Friday - date.DayOfWeek);
            return date;
        }

        /// <summary>
        /// Calculates the array of Swedish public holidays for a given year.
        /// </summary>
        /// <see cref="https://www.timeanddate.com/calendar/?year=2013&country=21"/>
        /// <param name="year">The year for which to calculate the Swedish holidays.</param>
        /// <returns>The array of Swedish public holidays for the input year.</returns>
        public static DateTime[] GetSwedishPublicHolidays(int year)
        {
            return GetSwedishPublicHolidaysAndTitle(year).Keys.ToArray();
        }

        /// <summary>
        /// Returns a dictionary of Swedish public holidays for the given year.
        /// </summary>
        /// <param name="year">The year for which to get the Swedish public holidays.</param>
        /// <returns>A dictionary of Swedish public holidays for the given year.</returns>
        public static Dictionary<DateTime, string> GetSwedishPublicHolidaysAndTitle(int year)
        {
            var easterSunday = GetEasterSunday(year);
            // Dictionary to store the holiday dates and names.
            var swedishHolidays = new Dictionary<DateTime, string>
            {
                { new DateTime(year, 1, 1), "New Year's Day" },
                { new DateTime(year, 1, 6), "Epiphany" },
                { new DateTime(year, 5, 1), "May Day" },
                { new DateTime(year, 6, 6), "National Day of Sweden" },
                { CalculateMidsummersEve(year).AddDays(1), "Midsummer's Day" },
                { CalculateAllSaintsEve(year).AddDays(1), "All Saints' Day" },
                { new DateTime(year, 12, 25), "Christmas Day" },
                { new DateTime(year, 12, 26), "Boxing Day" },
                { easterSunday.AddDays(-2), "Good Friday" },
                { easterSunday, "Easter Sunday" },
                { easterSunday.AddDays(1), "Easter Monday" },
                { easterSunday.AddDays(39), "Ascension Day" },
                { easterSunday.AddDays(49), "Whit Sunday" }
            };
            return swedishHolidays;
        }

        /// <summary>
        /// Calculates the date of All Saints' Eve (Alla helgons afton) in the Swedish calendar for the given year.
        /// </summary>
        /// <param name="year">The year for which to calculate All Saints' Eve.</param>
        /// <returns>The date of All Saints' Eve (Alla helgons afton) in the Swedish calendar for the given year.</returns>
        public static DateTime CalculateAllSaintsEve(int year)
        {
            // All Saints' Eve in Sweden is celebrated on the Saturday between October 30 and November 6.
            DateTime start = new DateTime(year, 10, 30);
            // Calculate the number of days between October 31 and the next Friday.
            // Add the number of days until Saturday to October 31 to get the date of All Saints' Eve.
            DateTime allSaintsEve = start.AddDays(DayOfWeek.Friday - start.DayOfWeek);
            return allSaintsEve;
        }

        /// <summary>
        /// Calculates the array of Swedish common local holidays for a given year.
        /// </summary>
        /// <see cref="https://www.timeanddate.com/calendar/?year=2013&country=21"/>
        /// <param name="year">The year for which to calculate the Swedish holidays.</param>
        /// <returns>The array of Swedish common local holidays for the input year.</returns>
        public static DateTime[] GetSwedishCommonLocalHolidays(int year)
        {
            return GetSwedishCommonLocalHolidaysAndTitle(year).Keys.ToArray();
        }

        /// <summary>
        /// Returns a dictionary of common local holidays in Sweden for the given year, including Twelfth Night, Holy Saturday, Walpurgis Night, Whit Saturday, Midsummer's Eve, All Saints' Eve, Christmas Eve, and New Year's Eve.
        /// </summary>
        /// <param name="year">The year for which to get the common local holidays in Sweden.</param>
        /// <returns>A dictionary of common local holidays in Sweden for the given year, with the date as the key and the holiday name as the value.</returns>
        public static Dictionary<DateTime, string> GetSwedishCommonLocalHolidaysAndTitle(int year)
        {
            var easterSunday = GetEasterSunday(year);
            var swedishHolidays = new Dictionary<DateTime, string>
            {
                { new DateTime(year, 1, 5), "Twelfth Night" },
                { easterSunday.AddDays(-1), "Holy Saturday" },
                { new DateTime(year, 4, 30), "Walpurgis Night" },
                { easterSunday.AddDays(48), "Whit Saturday" },
                { CalculateMidsummersEve(year), "Midsummer's Eve" },
                { CalculateAllSaintsEve(year), "All Saints' Eve" },
                { new DateTime(year, 12, 24), "Christmas Eve" },
                { new DateTime(year, 12, 31), "New Year's Eve" },
            };
            return swedishHolidays;
        }

        /// <summary>
        /// Calculates the date of Father's Day in the Swedish calendar for the given year.
        /// </summary>
        /// <param name="year">The year for which to calculate Father's Day.</param>
        /// <returns>The date of Father's Day in the Swedish calendar for the given year.</returns>
        public static DateTime CalculateFathersDay(int year)
        {
            // Father's Day in Sweden is celebrated on the second Sunday in November.
            DateTime start = new DateTime(year, 11, 1);
            DayOfWeek startDayOfWeek = start.DayOfWeek;

            // Calculate the number of days until the second Sunday in November.
            int daysUntilSunday = (int)DayOfWeek.Sunday - (int)startDayOfWeek;
            if (daysUntilSunday < 0)
                daysUntilSunday += 7;
            daysUntilSunday += 7;
            DateTime fathersDay = start.AddDays(daysUntilSunday);
            return fathersDay;
        }

        /// <summary>
        /// Calculates the date of Mother's Day in the Swedish calendar for the given year.
        /// </summary>
        /// <param name="year">The year for which to calculate Mother's Day.</param>
        /// <returns>The date of Mother's Day in the Swedish calendar for the given year.</returns>
        public static DateTime CalculateMothersDay(int year)
        {
            // Mother's Day in Sweden is celebrated on the last Sunday in May.
            DateTime lastDayInMay = new DateTime(year, 5, DateTime.DaysInMonth(year, 5));
            // Calculate the number of days until the next Sunday.
            // Add the number of days until Sunday to the last day in May to get the date of Mother's Day.
            DateTime mothersDay = lastDayInMay.AddDays(DayOfWeek.Sunday - lastDayInMay.DayOfWeek);

            return mothersDay;
        }

        /// <summary>
        /// Calculates the date of the specified Advent Sunday in the Swedish calendar for the given year.
        /// </summary>
        /// <param name="year">The year for which to calculate the Advent Sunday.</param>
        /// <param name="adventNumber">The number of the Advent Sunday to calculate (1, 2, 3, or 4).</param>
        /// <returns>The date of the specified Advent Sunday in the Swedish calendar for the given year.</returns>
        public static DateTime CalculateAdventSunday(int year, int adventNumber)
        {
            // Advent Sundays in Sweden fall on the fourth Sunday before Christmas.
            DateTime sundayBeforeChristmas = new DateTime(year, 12, 31);
            sundayBeforeChristmas = sundayBeforeChristmas.AddDays(DayOfWeek.Sunday - sundayBeforeChristmas.DayOfWeek);
            DateTime fourthSundayBeforeChristmas = sundayBeforeChristmas.AddDays(-28);
            DateTime adventSunday = fourthSundayBeforeChristmas.AddDays(7 * (adventNumber - 1));
            return adventSunday;
        }

        /// <summary>
        /// Calculates the array of Swedish typical non-working holidays for a given year.
        /// </summary>
        /// <see cref="https://www.timeanddate.com/calendar/?year=2013&country=21"/>
        /// <param name="year">The year for which to calculate the Swedish holidays.</param>
        /// <returns>The array of Swedish typical non-working holidays for the input year.</returns>
        public static DateTime[] GetSwedishTypicalNonWorkingHolidays(int year)
        {
            return GetSwedishTypicalNonWorkingHolidaysAndTitle(year).Keys.ToArray();
        }

        /// <summary>
        /// Returns an array of typical non-working holidays in Sweden for the given year, including Valentine's Day, Mother's Day, Father's Day, and the four Advent Sundays.
        /// </summary>
        /// <param name="year">The year for which to get the typical non-working holidays in Sweden.</param>
        /// <returns>An array of typical non-working holidays in Sweden for the given year.</returns>
        public static Dictionary<DateTime, string> GetSwedishTypicalNonWorkingHolidaysAndTitle(int year)
        {
            var adventSunday = CalculateAdventSunday(year, 1);
            var swedishHolidays = new Dictionary<DateTime, string>
            {
                { new DateTime(year, 2, 14), "Valentine's Day" },
                { CalculateMothersDay(year), "Mother's Day" },
                { CalculateFathersDay(year), "Father's Day" },
                { adventSunday, "First Advent Sunday" },
                { adventSunday.AddDays(1 * 7), "Second Advent Sunday" },
                { adventSunday.AddDays(2 * 7), "Third Advent Sunday" },
                { adventSunday.AddDays(3 * 7), "Fourth Advent Sunday" },
            };
            return swedishHolidays;
        }
    }
}
