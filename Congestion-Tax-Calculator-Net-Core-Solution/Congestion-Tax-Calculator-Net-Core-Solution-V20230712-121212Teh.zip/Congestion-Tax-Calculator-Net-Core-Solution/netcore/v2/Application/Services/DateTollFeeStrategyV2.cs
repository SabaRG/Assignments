﻿using congestion.calculator.v2.Application.Services.Interfaces;
using System;

namespace congestion.calculator.v2.Application.Services
{
    /// <summary>
    /// The current date toll fee calculation strategy is implemented in this class
    /// </summary>
    public class DateTollFeeStrategyV2 : IDateTollFeeStrategy
    {
        // TODO: Code Review 13n: [Need Team Agreement] I suggest to use uint instead of int for the return value
        // to avoid wrong answers strongly
        /// <summary>
        /// This method check a date and calculate its toll fee
        /// </summary>
        /// <param name="date">the input date for toll fee calculation</param>
        /// <returns>the calculated toll fee value for the input date between 0 to int.MaxValue</returns>
        public int GetDateTollFee(DateTime date)
        {
            if (IsTollFreeDate(date)) return 0;
            int hour = date.Hour;
            int minute = date.Minute;

            // TODO: Code Review 20n: When I generate test case, I found that the DateTime handle this issue and it can be 
            // ignored (the next two lines can be removed). I have to comment them to avoid decreasing code coverage.
            // if (hour < 0 || hour > 23 || minute < 0 || minute > 59)
            //    throw new ArgumentOutOfRangeException($"Wrong date value for hour or minute in {date}");

            if (hour == 6 && minute >= 0 && minute <= 29) return 8;
            else if (hour == 6 && minute >= 30 && minute <= 59) return 13;
            else if (hour == 7 && minute >= 0 && minute <= 59) return 18;
            else if (hour == 8 && minute >= 0 && minute <= 29) return 13;
            else if (hour == 8 && minute >= 30 ||
                hour >= 9 && hour <= 13 ||
                hour == 14 && minute <= 59) return 8;
            else if (hour == 15 && minute >= 0 && minute <= 29) return 13;
            else if (hour == 15 && minute >= 30 || hour == 16 && minute <= 59) return 18;
            else if (hour == 17 && minute >= 0 && minute <= 59) return 13;
            else if (hour == 18 && minute >= 0 && minute <= 29) return 8;
            return 0;
        }

        /// <summary>
        /// This method check a date that is toll free or not.
        /// List of National and Regional Public Holidays of Sweden in 2013:
        /// https://www.calendarlabs.com/holidays/sweden/2013
        /// </summary>
        /// <param name="date">the input date</param>
        /// <returns>true if the given date is toll free, otherwise false</returns>
        private bool IsTollFreeDate(DateTime date)
        {
            int year = date.Year;
            int month = date.Month;
            int day = date.Day;
            if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday) return true;

            return year == 2013 &&
                month == 1 && day == 1 ||
                month == 3 && (day == 28 || day == 29) ||
                month == 4 && (day == 1 || day == 30) ||
                // TODO: Code Review 23: [Need Team Agreement] The above calendar mentioned that 'Monday May 20, 2013' is Whit Monday
                //  as a holiday. I am not familiar with their calendar, but must we add `day == 20` to this condition based on
                //  the rule `The tax is not charged on public holidays` of specification?
                month == 5 && (day == 1 || day == 8 || day == 9) ||
                month == 6 && (day == 5 || day == 6 || day == 21) ||
                month == 7 || /* for July */
                // TODO: Code Review 24: [Need Team Agreement] The above calendar mentioned that 'Friday Nov 01, 2013' is All Saints Day
                // as a holiday that is considered in the next condition, but the previous day is Thursday and is not considered in
                // other conditions. So, we should add the following code too?
                // month == 10 && day == 31 ||
                // Also, I think it is very dangerous to check holidays and their previous day in this form!
                // It can be very messy and it is not easy to use and modify. We should have a list of holidays and check their
                // previous day using calculating code, not a hard code! Are we sure that we are really software developer, not Excel operator?! :-)
                // Please let to rebuild this code and made a new one! I hope somebody help to improve this code at least using ChatGPT.
                month == 11 && day == 1 ||
                // TODO: Code Review 25: [Need Team Agreement] if we have 31 as holiday, and as I see, it is Tuesday, why we don't add 30?
                // I hope you accept CR24.
                month == 12 && (day == 24 || day == 25 || day == 26 || day == 31);
        }
    }
}

/*
  month == 3 && (day == 28 || day == 29) ||
  month == 4 && (day == 1 || day == 30) ||
*/