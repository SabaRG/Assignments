﻿using congestion.calculator.v2.Application.Services.Interfaces;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace congestion.calculator.v2.Application.Services
{
    /// <summary>
    /// The current vehicle toll fee calculation strategy is implemented in this class
    /// </summary>    
    [ExcludeFromCodeCoverage]
    [Obsolete("This class has many bugs and should not be used any more, please use V2", false)]
    public class VehicleTollFeeStrategyV1 : IVehicleTollFeeStrategy
    {
        /// <summary>
        /// This method check a vehicle to be toll free or not.
        /// </summary>
        /// <param name="vehicle">the input vehicle for checking</param>
        /// <returns>true if the input vehicle is free of toll fee, otherwise false</returns>
        public bool IsVehicleTollFree(IVehicle vehicle)
        {
            if (vehicle == null) return false;
            string vehicleType = vehicle.GetVehicleType();
            // TODO: Code Review 12: this code can be written as the following to be faster than the current implementation
            // but I don't use it due to higher modifiability of TollFreeVehicles names and higher reliability of current method.
            //
            // vehicleType = char.ToUpper(vehicleType[0]) + vehicleType.Substring(1).ToLower(); // this line is a simple implementation of ToCapitalCase
            // return Enum.GetNames(typeof(TollFreeVehicles)).Any(name => name.Equals(vehicleType));
            //
            // Even though we can use a static property to keep the lower case of TollFreeVehicles names once and
            // use that to implement this method faster as the following:
            // 
            // static string[] TollFreeVehiclesLowerNames = Enum.GetNames(typeof(TollFreeVehicles)).Select(n => n.ToLower()).ToArray(); // in class scope, not this method
            // string vehicleType = vehicle.GetVehicleType().ToLower();
            // return TollFreeVehiclesLowerNames.Contains(vehicleType);
            //
            // this TODO should be removed after training the developers.
            return Enum.GetNames(typeof(TollFreeVehicles)).Any(name => name.Equals(vehicleType, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// This enum contains the names of current toll free vehicles based on this strategy
        /// Convention: All names should be in Capital case
        /// </summary>
        private enum TollFreeVehicles
        {
            Motorcycle = 0,
            // TODO: Code Review 26: [Need Team Agreement] Are you really kidding me?! :-) The tractor is not in the specification for `Tax Exempt vehicles` section! 
            // As you use a string comparison for free vehicles, it is also hard to be find without code review or
            // white box testing approaches. I think we need a retrospective meeting to find how this bug is produced and
            // avoid it for the next time.
            // Besides, this modifies show the importance of CR11
            Tractor = 1,
            Emergency = 2,
            Diplomat = 3,
            Foreign = 4,
            Military = 5
            // TODO: Code Review 27: [Need Team Agreement] Unlike the tractor, these two vehicle were in the specification that are not considered in the code.
            // 
            // Besides, I want to have a private chat with my junior colleague and tell him:
            // if you want to work with me again in the future, please be very careful.
            // I can't accept any excuse for these kind of bugs in a real-world critical financial system!
            // and please uncomment the following commented code to add this code based on the specification.
            // Even I decide to add new V2 of this class after all these consideration,
            // but I have another suggestion that avoid assigning values to this Enum and also reorder the names based on
            // the specification for easily reviewing the code. We have this convention in team.

            // Bus,    

        }
    }
}
