﻿using congestion.calculator.v2.Application.Services.Interfaces;
using System;
using System.Diagnostics.CodeAnalysis;

namespace congestion.calculator.v2.Application.Services
{
    /// <summary>
    /// This is the main class for CongestionTaxCalculator of a vehicle in several days.
    /// It is a re engineered version of the main assignment, but as it has many bugs, 
    /// I defined it as an obsolete class to warn anybody that instantiate it and also I exclude it from code coverage.
    /// </summary>
    [ExcludeFromCodeCoverage]
    [Obsolete("This class has many bugs and should not be used any more, please use V2", false)]
    public class CongestionTaxCalculatorV1 : ICongestionTaxCalculatorStrategy
    {
        ITollFeeCalculatorStrategy tollFeeCalculator;

        public CongestionTaxCalculatorV1(ITollFeeCalculatorStrategy TollFeeCalculator)
        {
            tollFeeCalculator = TollFeeCalculator;
        }

        // TODO: Code Review 17: [Need Team Agreement] I suggest to use uint instead of int for the return value to avoid wrong answers strongly
        /// <summary>
        /// This method must calculate and return toll fee for different vehicles and dates, even though it has many bugs now.
        /// </summary>
        /// <param name="vehicle"></param>
        /// <param name="dates"></param>
        /// <returns></returns>
        public int GetTax(IVehicle vehicle, DateTime[] dates)
        {
            DateTime intervalStart = dates[0];
            int totalFee = 0;
            foreach (DateTime date in dates)
            {
                // TODO: Code Review 30: [Need Team Agreement] (Critical) This code wants to implement `The single charge rule` but it just check a pair of tolling stations, even though it is possible that we have more than
                // two stations in 60 minute, e.g. 5 stations. In this case, the specification is ambiguous! 
                // For example consider somebody driving into and out of Gothenburg every 5 minutes. Now, how the tax should be
                // calculated? From the first passing through to the next 60 minutes, all the passing tax must be calculated
                // and their maximum must be considered? I assumed yes, then after 60 minutes, other passing should be checked
                // with which old passing? the second one (as a time window)? the last one (that is considered until now within 60 minutes)?
                // All passing before the 60 minutes, must be deleted and don't be considered again for the new passing?
                int nextFee = tollFeeCalculator.GetTollFee(vehicle, date);
                int tempFee = tollFeeCalculator.GetTollFee(vehicle, intervalStart);

                // TODO: Code Review 31: [Need Team Agreement] We can use the following code instead of two next lines.
                // long minutes = (date - intervalStart).TotalMinutes;
                long diffInMillies = date.Millisecond - intervalStart.Millisecond;
                long minutes = diffInMillies / 1000 / 60;
                if (minutes <= 60)
                {
                    if (totalFee > 0) totalFee -= tempFee;
                    if (nextFee >= tempFee) tempFee = nextFee;
                    totalFee += tempFee;
                }
                else
                {
                    totalFee += nextFee;
                }
                #region CR32
                // TODO: Code Review 32: [Need Team Agreement] The `intervalStart` variable is not updated for the next round. In this condition, we always new `date` with just the first `date` of the given list that it is not valid
                // based on the requirements! We should add the following commented code here exactly at the end of the loop:
                // intervalStart = date;
                #endregion CR32

                #region CR33 
                // TODO: Code Review 33: [Need Team Agreement] You are comparing the new `date` with the previous `date` to check their span is within 60 minutes or not, but how are you sure that the `dates` is sorted?
                // As the "2013-02-08 06:27:00" and "2013-02-08 06:20:27" samples in the `Scenario` examples of the specification
                // are not sorted and are consecutive.
                // You must write the above for loop as the following for this assumption (replace it with the current loop):
                // foreach (DateTime date in dates.OrderBy(d => d))
                #endregion CR33

                // TODO: Code Review 34: [Need Team Agreement] If we consider the CR32 and CR33, still we have a wonderful bug! The current code consider just a pair of tolling station, but this approach has a bug because it is not valid 
                // and as required based on the specification.
                // For example consider this scenario that a vehicle every 50 minutes driving into and then after 50 minutes
                // driving out of Gothenburg. How much this driver will pay in the current implementation scenario?!
                // e.g.:
                // Round    Time         Tax
                // 01       06:05 in  -> SEK 8
                // 02       06:55 out -> SEK 13
                // 03       07:45 in  -> SEK 18
                // 04       08:35 out -> SEK 8
                // 05       09:25 in  -> SEK 8
                // 06       10:15 out -> SEK 8
                // 07       11:05 in  -> SEK 8
                // 08       12:55 out -> SEK 8
                // 09       13:45 in  -> SEK 8
                // 10       14:35 out -> SEK 8
                // 11       15:25 in  -> SEK 13
                // 12       16:15 out -> SEK 18
                // 13       17:05 in  -> SEK 13
                // 14       18:55 out -> SEK 0
                // In all pairs, the time difference is less than 60 minutes. So, all the times, the IF statement of this loop
                // will be run.
                // The first round totalFee will be increased by 8 (totalFee: 8),
                // the second round it will be decreased by 8 and then increased by 13 (totalFee: 13).
                // The third round, we will decreased by 13 again and increased by 18 (totalFee: 18).
                // The fourth round, we will decreased by 18 again and increased by 18 (totalFee: 18).
                // The fifth round, we will decreased by 8 (!) and increased by 8 (totalFee: 18).
                // The sixth round, we will decreased by 8 (!) and increased by 8 (totalFee: 18).
                // The seventh round, we will decreased by 8 (!) and increased by 8 (totalFee: 18).
                // The eighth round, we will decreased by 8 (!) and increased by 8 (totalFee: 18).
                // The ninth round, we will decreased by 8 (!) and increased by 8 (totalFee: 18).
                // The tenth round, we will decreased by 8 (!) and increased by 8 (totalFee: 18).
                // The eleventh round, we will decreased by 8 (!) and increased by 13 (totalFee: 18-8+13=23).
                // The twelfth round, we will decreased by 13 (!) and increased by 18 (totalFee: 23-13+18=28).
                // The thirteenth round, we will decreased by 18 (!) and increased by 18 (totalFee: 28).
                // The fourteenth round, we will decreased by 13 (!) and increased by 13 (totalFee: 28).
                //
                // Is this the really required behavior?!
                // Besides, I can't implement it myself unless the CR30 can be solve for me. 
                // So, in the V2 of this class, I just add CR31 and CR32 and I know that version is not behave correctly.

                // TODO: Code Review 35: [Need Team Agreement] New comment: I asked the ChatGPT about this ambiguity and it said: "This is a real law in Gothenburg, Sweden, which is applied to calculate toll fees for road users.
                //    Under this law, if a vehicle passes several toll stations within 60 minutes, it is only taxed once, and the amount that must be paid is the highest one. For example, if a vehicle passes five toll stations within
                //    a 60 - minute period, it calculates the toll fees for all the passes between the first and last passes during that 60 minutes, and considers the highest amount as the final cost.Then, after 60 minutes, the toll fees for all
                //    new passes are calculated again using the same method. In this law, passes that occurred within the previous 60 minutes must be removed and not considered in future calculations."
                // So, as I have no access to stakeholders and analyzers, I implement this specification. If it found that it's wrong,
                // then I have to re-implement it.

            }
            // TODO: Code Review 36: [Need Team Agreement] I think you are not kidding me, my lovely junior college, you are killing me! The maximum 60 SEK is just for a day not all dates during various dates that can be in different days!
            // The next line is invalid based on specifications! :| ;)
            // It is interesting that when I describe the specification for ChatGPT and ask it to generate the code, it produce a code like this version as the following! I think you -my lovely junior college- do the same thing. Please try to be a real 
            // programmer not just a copy-paster without thinking like that robot! It's ChatGPT code:
            // public int GetTax(IVehicle vehicle, DateTime[] dates)
            // {
            //    int totalTax = 0;
            //    var orderedDates = dates.OrderBy(d => d).ToList(); // sort the dates in ascending order
            //    DateTime lastChargeDate = DateTime.MinValue;
            //    int lastCharge = 0;

            //    foreach (var date in orderedDates)
            //    {
            //        int charge = GetTollFee(vehicle, date); // get the toll fee for the current date
            //        if (date <= lastChargeDate.AddMinutes(60)) // check if the current date is within 60 minutes from the last charge
            //        {
            //            if (charge > lastCharge)
            //            {
            //                totalTax -= lastCharge; // subtract the previous charge from the total tax
            //                totalTax += charge; // add the new charge to the total tax
            //                lastCharge = charge; // update the last charge
            //            }
            //        }
            //        else
            //        {
            //            totalTax += charge; // add the current charge to the total tax
            //            lastCharge = charge; // update the last charge
            //            lastChargeDate = date; // update the last charge date
            //        }
            //    }

            //    return totalTax;
            // }
            if (totalFee > 60) totalFee = 60;
            return totalFee;
        }
    }
}
