﻿using congestion.calculator.v2.Domain.Models;
using congestion.calculator.v2.Domain.ValueObjects;
using congestion.calculator.v2.Infrastructure.Repositories;
using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;

namespace congestion.calculator.v2.Infrastructure.Providers
{
    /// <summary>
    /// Represents a repository for retrieving tax rules from a CSV file.
    /// </summary>
    public class CSVTaxRuleRepository : ITaxRuleRepository
    {
        private readonly string _filePath;

        /// <summary>
        /// Initializes a new instance of the CSVTaxRuleRepository class.
        /// </summary>
        /// <param name="filePath">The path to the CSV file containing tax rules.</param>
        public CSVTaxRuleRepository(string filePath)
        {
            _filePath = filePath;
        }

        /// <summary>
        /// Retrieves all tax rules for a specified city.
        /// </summary>
        /// <param name="city">The city for which to retrieve tax rules.</param>
        /// <returns>A list of TaxRuleDTO objects representing the tax rules for the specified city.</returns>
        public List<TaxRuleDTO> GetAllRules(string city)
        {
            var rules = new List<TaxRuleDTO>();
            //CultureInfo.InvariantCulture
            using (var reader = new StreamReader(_filePath))
            using (var csv = new CsvReader(reader,
                new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    HasHeaderRecord = true,
                    NewLine = Environment.NewLine,
                    Delimiter = ",",
                    //PrepareHeaderForMatch = args => args.Header.ToLower(),
                    //MissingFieldFound = null
                }))
            {
                csv.Context.RegisterClassMap<TaxRuleMap>();
                while (csv.Read())
                {
                    var rule = csv.GetRecord<TaxRuleDTO>();
                    if (rule.City.Equals(city, StringComparison.OrdinalIgnoreCase))
                        rules.Add(rule);
                }
            }
            return rules;
        }

        [ExcludeFromCodeCoverage]
        private sealed class TaxRuleMap : CsvHelper.Configuration.ClassMap<TaxRuleDTO>
        {
            public TaxRuleMap()
            {
                Map(m => m.City).Index(0);
                Map(m => m.StarTime).Index(1).TypeConverter<TimeConverter>();
                Map(m => m.EndTime).Index(2).TypeConverter<TimeConverter>();
                Map(m => m.Fee).Index(3);
            }
        }

        [ExcludeFromCodeCoverage]
        public class TimeConverter : ITypeConverter
        {
            public object ConvertFromString(string text, IReaderRow row, MemberMapData memberMapData)
            {
                return new Time(text);
            }

            
            public string ConvertToString(object value, IWriterRow row, MemberMapData memberMapData)
            {
                return value.ToString();
            }
        }
    }
}
