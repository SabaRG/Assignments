using congestion.calculator.v2.Domain.Models;
using congestion.calculator.v2.Domain.ValueObjects;
using congestion.calculator.v2.Infrastructure.Repositories;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace congestion.calculator.v2.Infrastructure.Providers
{
    /// <summary>
    /// Represents a repository for retrieving tax rules from a file.
    /// </summary>
    public class MDTaxRuleRepository : ITaxRuleRepository
    {
        private readonly string _filePath;

        /// <summary>
        /// Initializes a new instance of the MDTaxRuleRepository class.
        /// </summary>
        /// <param name="filePath">The path to the file containing tax rules.</param>
        public MDTaxRuleRepository(string filePath)
        {
            _filePath = filePath;
        }

        /// <summary>
        /// Retrieves all tax rules for a specified city.
        /// </summary>
        /// <param name="city">The city for which to retrieve tax rules.</param>
        /// <returns>A list of TaxRuleDTO objects representing the tax rules for the specified city.</returns>
        public List<TaxRuleDTO> GetAllRules(string city)
        {
            var rules = new List<TaxRuleDTO>();

            using (var reader = new StreamReader(_filePath))
            {
                // Skip the header line
                reader.ReadLine();
                // Skip the separator line
                reader.ReadLine();

                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Trim().Trim('|').Split('|')
                        .Select(v => v.Trim()).ToList();

                    // Convert Amount to int
                    var amount = int.Parse(values[3].Replace("SEK", string.Empty).Trim());

                    // Convert Start Time and End Time to TimeSpan
                    var startTime = new Time(values[1]);
                    var endTime = new Time(values[2]);

                    var rule = new TaxRuleDTO
                    {
                        City = values[0],
                        StarTime = startTime,
                        EndTime = endTime,
                        Fee = amount
                    };
                    if (rule.City.Equals(city, StringComparison.OrdinalIgnoreCase))
                        rules.Add(rule);
                }
            }
            return rules;
        }
    }
}
