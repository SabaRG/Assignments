﻿using congestion.calculator.v2.Domain.Models;
using System.Collections.Generic;

namespace congestion.calculator.v2.Infrastructure.Repositories
{
    /// <summary>
    /// An interface for a repository that provides tax rules for a specific city.
    /// </summary>
    public interface ITaxRuleRepository
    {
        /// <summary>
        /// Retrieves a list of tax rules for the specified city.
        /// </summary>
        /// <param name="city">The name of the city for which to retrieve tax rules.</param>
        /// <returns>A list of tax rule DTOs for the specified city.</returns>
        List<TaxRuleDTO> GetAllRules(string city);
    }
}
