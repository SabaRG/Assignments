﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq.Expressions;

namespace congestion.calculator.v2.Domain.ValueObjects
{
    /// <summary>
    /// A class for representing a time of day. 
    /// </summary>
    public class Time : IComparable<Time>, IComparable<DateTime>
    {
        private DateTime _time;

        /// <summary>
        /// Initializes a new instance of the Time class using a number of ticks without 
        /// considering the date part (year, month, day).
        /// </summary>
        /// <param name="ticks">A number of ticks.</param>
        public Time(long ticks)
        {
            _time = new DateTime(ticks);
            _time = new DateTime(1, 1, 1, _time.Hour, _time.Minute, _time.Second, _time.Millisecond);
        }

        /// <summary>
        /// Initializes a new instance of the Time class using hours, minutes, seconds, and milliseconds.
        /// </summary>
        /// <param name="hour">The hour component of the time.</param>
        /// <param name="minute">The minute component of the time.</param>
        /// <param name="second">The second component of the time.</param>
        /// <param name="millisecond">The millisecond component of the time.</param>
        public Time(int hour = 0, int minute = 0, int second = 0, int millisecond = 0)
        {
            _time = new DateTime(1, 1, 1, hour, minute, second, millisecond);
        }

        /// <summary>
        /// Initializes a new instance of the Time class using a DateTime object.
        /// </summary>
        /// <param name="dt">A DateTime object.</param>
        public Time(DateTime dt)
            : this(dt.Ticks) { }

        public static DateTime TryParse(string timeString)
        {
            DateTime time;
            if (!DateTime.TryParseExact(timeString, new[] { "HH:mm", "HH:mm:ss", "HH:mm:ss.fff"
                //, "hh:mm", "hh:mm:ss", "hh:mm:ss.fff" 
                    }, CultureInfo.InvariantCulture, DateTimeStyles.None, out time))
            {
                throw new FormatException("Invalid time format.");
            }
            return time;
        }

        /// <summary>
        /// Initializes a new instance of the Time class using a time string.
        /// </summary>
        /// <param name="timeString">A string that represents a time in the format "hh:mm:ss.fff".</param>
        public Time(string timeString)
            : this(TryParse(timeString))
        {
        }

        /// <summary>
        /// Gets or sets the time of day as a DateTime object.
        /// </summary>
        public DateTime AsDateTime
        {
            get => _time;
            [ExcludeFromCodeCoverage]
            private set
            {
                //if (value.Hour < 0 || value.Hour > 23)
                //{
                //    throw new ArgumentOutOfRangeException(nameof(value.Hour), "Hour must be between 0 and 23.");
                //}

                //if (value.Minute < 0 || value.Minute > 59)
                //{
                //    throw new ArgumentOutOfRangeException(nameof(value.Minute), "Minute must be between 0 and 59.");
                //}

                //if (value.Second < 0 || value.Second > 59)
                //{
                //    throw new ArgumentOutOfRangeException(nameof(value.Second), "Second must be between 0 and 59.");
                //}

                _time = new DateTime(1, 1, 1, value.Hour, value.Minute, value.Second, value.Millisecond);
            }
        }

        /// <summary>
        /// Compares the current Time object with another Time object.
        /// </summary>
        /// <param name="other">The Time object to compare with.</param>
        /// <returns>A value that indicates the relative order of the Time objects being compared.</returns>
        public int CompareTo(Time other)
        {
            if (other == null)
                return 1;
            return AsDateTime.CompareTo(other.AsDateTime);
        }

        /// <summary>
        /// Determines whether the current Time object is equal to another object.
        /// </summary>
        /// <param name="obj">The object to compare with the current Time object.</param>
        /// <returns>true if the current Time object is equal to the other object; otherwise, false.</returns>
        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            if (ReferenceEquals(this, obj))
                return true;
            if (obj.GetType() != GetType())
                return false;
            return AsDateTime.Equals(((Time)obj).AsDateTime);
        }

        /// <summary>
        /// Returns a hash code for the current Time object.
        /// </summary>
        /// <returns>A hash code for the current Time object.</returns>
        public override int GetHashCode()
        {
            return AsDateTime.GetHashCode();
        }

        /// <summary>
        /// Determines whether two Time objects are equal.
        /// </summary>
        /// <param name="left">The first Time object to compare.</param>
        /// <param name="right">The second Time object to compare.</param>
        /// <returns>true if the two Time objects are equal; otherwise, false.</returns>
        public static bool operator ==(Time left, Time right)
        {
            if (ReferenceEquals(left, right))
                return true;
            if (left is null || right is null)
                return false;
            return left.Equals(right);
        }

        /// <summary>
        /// Determines whether two Time objects are not equal.
        /// </summary>
        /// <param name="left">The first Time object to compare.</param>
        /// <param name="right">The second Time object to compare.</param>
        /// <returns>true if the two Time objects are not equal; otherwise, false.</returns>
        public static bool operator !=(Time left, Time right)
        {
            return !(left == right);
        }

        /// <summary>
        /// Determines whether one Time object is less than another Time object.
        /// </summary>
        /// <param name="left">The first Time object to compare.</param>
        /// <param name="right">The second Time object to compare.</param>
        /// <returns>true if the first Time object is less than the second Time object; otherwise, false.</returns>
        public static bool operator <(Time left, Time right)
        {
            if (left is null)
                return right is object;

            return left.CompareTo(right) < 0;
        }

        /// <summary>
        /// Determines whether one Time object is less than or equal to another Time object.
        /// </summary>
        /// <param name="left">The first Time object to compare.</param>
        /// <param name="right">The second Time object to compare.</param>
        /// <returns>true if the first Time object is less than or equal to the second Time object; otherwise, false.</returns>
        public static bool operator <=(Time left, Time right)
        {
            if (left is null)
                return true;
            return left.CompareTo(right) <= 0;
        }

        /// <summary>
        /// Determines whether one Time object is greater than another Time object.
        /// </summary>
        /// <param name="left">The first Time object to compare.</param>
        /// <param name="right">The second Time object to compare.</param>
        /// <returns>true if the first Time object is greater than the second Time object; otherwise, false.</returns>
        public static bool operator >(Time left, Time right)
        {
            return !(left <= right);
        }

        /// <summary>
        /// Determines whether one Time object is greater than or equal to another Time object.
        /// </summary>
        /// <param name="left">The first Time object to compare.</param>
        /// <param name="right">The second Time object to compare.</param>
        /// <returns>true if the first Time object is greater than or equal to the second Time object; otherwise, false.</returns>
        public static bool operator >=(Time left, Time right)
        {
            return !(left < right);
        }

        /// <summary>
        /// This operator is used to compare a Time object with a DateTime object.
        /// </summary>
        /// <param name="left">The initial Time object.</param>
        /// <param name="right">The second DateTime object.</param>
        /// <returns>True if the two objects are equal, false otherwise.</returns>
        public static bool operator ==(Time left, DateTime right)
        {
            if (left is null)
                return false;
            return left.AsDateTime.Equals(new Time(right).AsDateTime);
        }

        /// <summary>
        /// This operator is used to compare a Time object with a DateTime object.
        /// </summary>
        /// <param name="left">The initial Time object.</param>
        /// <param name="right">The second DateTime object.</param>
        /// <returns>True if the two objects are not equal, false otherwise.</returns>
        public static bool operator !=(Time left, DateTime right)
        {
            return !(left == right);
        }

        /// <summary>
        /// This operator is used to compare a Time object with a DateTime object.
        /// </summary>
        /// <param name="left">The initial Time object.</param>
        /// <param name="right">The second DateTime object.</param>
        /// <returns>True if the left object is less than the right object, false otherwise.</returns>
        public static bool operator <(Time left, DateTime right)
        {
            if (left is null)
                return right is object;
            return left.CompareTo(new Time(right).AsDateTime) < 0;
        }

        /// <summary>
        /// This operator is used to compare a Time object with a DateTime object.
        /// </summary>
        /// <param name="left">The initial Time object.</param>
        /// <param name="right">The second DateTime object.</param>
        /// <returns>True if the left object is less than or equal to the right object, false otherwise.</returns>
        public static bool operator <=(Time left, DateTime right)
        {
            if (left is null)
                return true;
            return left.CompareTo(new Time(right).AsDateTime) <= 0;
        }

        /// <summary>
        /// This operator is used to compare a Time object with a DateTime object.
        /// </summary>
        /// <param name="left">The initial Time object.</param>
        /// <param name="right">The second DateTime object.</param>
        /// <returns>True if the left object is greater than the right object, false otherwise.</returns>
        public static bool operator >(Time left, DateTime right)
        {
            return !(left <= right);
        }

        /// <summary>
        /// This operator is used to compare a Time object with a DateTime object.
        /// </summary>
        /// <param name="left">The initial Time object.</param>
        /// <param name="right">The second DateTime object.</param>
        /// <returns>True if the left object is greater than or equal to the right object, false otherwise.</returns>
        public static bool operator >=(Time left, DateTime right)
        {
            return !(left < right);
        }

        /// <summary>
        /// Returns a string that represents the current Time object in the format "hh:mm:ss.fff".
        /// </summary>
        /// <returns>A string that represents the current Time object in the format "hh:mm:ss.fff".</returns>
        public override string ToString()
        {
            if (AsDateTime.Millisecond == 0)
            {
                if (AsDateTime.Second == 0)
                {
                    if (AsDateTime.Minute == 0)
                        return _time.ToString("HH");
                    return _time.ToString("HH\\:mm");
                }
                return _time.ToString("HH\\:mm\\:ss");
            }
            return _time.ToString("HH\\:mm\\:ss.fff");
        }

        /// <summary>
        /// Compares the current Time object with a DateTime object.
        /// </summary>
        /// <param name="other">The DateTime object to compare with.</param>
        /// <returns>A value that indicates the relative order of the Time and DateTime objects being compared.</returns>
        public int CompareTo(DateTime other)
        {
            return AsDateTime.CompareTo(new Time(other).AsDateTime);
        }
    }

    /// <summary>
    /// A dummy try to add ToTime method to static Convert class that was impossible now
    /// even though it let other classes to convert strings to Time like:
    /// (null as DateTime).ToTime("12:24")
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class Extensions
    {
        /// <summary>
        /// This method let to convert a DateTime object simply to a Time object with a method of DateTime objects
        /// </summary>
        /// <param name="this">The input DateTime object</param>
        /// <returns>The converted Time result from the input DateTime object</returns>
        public static Time ToTime(this DateTime @this)
        {
            return new Time(@this);
        }

        /// <summary>
        /// This method let to convert a string object simply to a Time object with a method of string objects
        /// </summary>
        /// <param name="this">The input string object</param>
        /// <returns>The converted Time result from the input string object</returns>
        public static Time ToTime(this string @this)
        {
            return new Time(@this);
        }

        /// <summary>
        /// This utility method let to check a Time object is in range of two other Time objects (not equal to boundaries)
        /// </summary>
        /// <param name="this">The input string object</param>
        /// <param name="from">The start range of time</param>
        /// <param name="to">The end range of time</param>
        /// <returns>a boolean value which is true if from&lt;This Time&lt;to</returns>
        public static bool Between(this Time @this, Time from, Time to)
        {
            return from < @this && @this < to;
        }

        /// <summary>
        /// This utility method let to check a Time object is in range of two other Time objects or equal to boundaries
        /// </summary>
        /// <param name="this">The input string object</param>
        /// <param name="from">The start range of time</param>
        /// <param name="to">The end range of time</param>
        /// <returns>a boolean value which is true if from≤This Time≤to</returns>
        public static bool BetweenOrEqualBothSides(this Time @this, Time from, Time to)
        {
            return from <= @this && @this <= to;
        }

        /// <summary>
        /// This utility method let to check a Time object is in range of two other Time objects or just equal to left boundary
        /// </summary>
        /// <param name="this">The input string object</param>
        /// <param name="from">The start range of time</param>
        /// <param name="to">The end range of time</param>
        /// <returns>a boolean value which is true if from&lt;This Time≤to</returns>
        public static bool BetweenOrEqualLeftSide(this Time @this, Time from, Time to)
        {
            return from <= @this && @this < to;
        }

        /// <summary>
        /// This utility method let to check a Time object is in range of two other Time objects or just equal to left boundary
        /// </summary>
        /// <param name="this">The input string object</param>
        /// <param name="from">The start range of time</param>
        /// <param name="to">The end range of time</param>
        /// <returns>a boolean value which is true if from≤This Time&lt;to</returns>
        public static bool BetweenOrEqualRightSide(this Time @this, Time from, Time to)
        {
            return from < @this && @this <= to;
        }

        public static Time ToTime(this Time @this, string timeString)
        {
            return new Time(timeString);
        }

        public static T ToTime<T>(this T @this, string timeString)
        where T : class, new()
        {
            return Utility<T>.ToTime(timeString);
        }
    }

    [ExcludeFromCodeCoverage]
    public static class Utility<T>
    where T : class, new()
    {
        static Utility()
        {
            ToTime = Expression.Lambda<Func<string, T>>(Expression.New(typeof(T).GetConstructor(Type.EmptyTypes))).Compile();
        }
        public static Func<string, T> ToTime { get; private set; }
    }
}
