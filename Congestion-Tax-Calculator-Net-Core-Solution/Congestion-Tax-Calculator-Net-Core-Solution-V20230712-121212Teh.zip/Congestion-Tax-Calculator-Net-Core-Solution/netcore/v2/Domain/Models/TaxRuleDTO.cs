﻿using congestion.calculator.v2.Domain.ValueObjects;
using System;

namespace congestion.calculator.v2.Domain.Models
{
    /// <summary>
    /// A data transfer object that represents a tax rule for a specific city.
    /// </summary>
    public class TaxRuleDTO
    {
        /// <summary>
        /// The name of the city to which the tax rule applies.
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// The starting time of day when the tax rule is in effect.
        /// The rule include the start time (must b equal)
        /// </summary>
        public Time StarTime { get; set; }

        /// <summary>
        /// The ending time of day when the tax rule is in effect.
        /// </summary>
        public Time EndTime { get; set; }

        /// <summary>
        /// The amount of tax (in a certain currency) that applies during the specified time period.
        /// </summary>
        public int Fee { get; set; }

        /// <summary>
        /// Returns a string representation of the tax rule object.
        /// </summary>
        /// <returns>A string containing the city name, start and end times, and tax fee.</returns>
        public override string ToString() => $"City: {City}, StartTime: {StarTime}, EndTime: {EndTime}, Fee: {Fee}";

        /// <summary>
        /// Determines whether the specified object is equal to the current tax rule object.
        /// </summary>
        /// <param name="obj">The object to compare with the current object.</param>
        /// <returns>True if the objects are equal; otherwise, false.</returns>
        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            if (ReferenceEquals(this, obj))
                return true;
            if (obj.GetType() != GetType())
                return false;
            var trd = obj as TaxRuleDTO;
            return City.Equals(trd.City, StringComparison.OrdinalIgnoreCase) &&
                StarTime.Equals(trd.StarTime) &&
                EndTime.Equals(trd.EndTime) &&
                Fee.Equals(trd.Fee);
        }
    }
}
