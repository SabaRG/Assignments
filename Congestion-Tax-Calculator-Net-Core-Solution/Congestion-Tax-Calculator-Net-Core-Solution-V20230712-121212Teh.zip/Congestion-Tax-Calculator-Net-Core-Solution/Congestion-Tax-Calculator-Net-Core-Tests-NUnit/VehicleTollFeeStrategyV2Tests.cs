using NUnit.Framework;
using congestion.calculator;
using congestion.calculator.v2.Application.Services;

namespace Congestion_Tax_Calculator_Net_Core_Tests_NUnit
{


    [TestFixture]
    public class VehicleTollFeeStrategyV2Tests
    {
        public class Emergency : IVehicle
        {
            public string GetVehicleType()
            {
                return "Emergency";
            }
        }

        public class Diplomat : IVehicle
        {
            public string GetVehicleType()
            {
                return "Diplomat";
            }
        }

        public class Military : IVehicle
        {
            public string GetVehicleType()
            {
                return "Military";
            }
        }

        public class Foreign : IVehicle
        {
            public string GetVehicleType()
            {
                return "Foreign";
            }
        }

        public class Motorcycle : IVehicle
        {
            public string GetVehicleType()
            {
                return "Motorcycle";
            }
        }

        public class Bus : IVehicle
        {
            public string GetVehicleType()
            {
                return "Bus";
            }
        }

        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsEmergency()
        {
            // Arrange
            var vehicleTollFeeStrategy = new VehicleTollFeeStrategyV2();
            var vehicle = new Emergency();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsTrue(isTollFree);
        }

        [Test]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsBus()
        {
            // Arrange
            var vehicleTollFeeStrategy = new VehicleTollFeeStrategyV2();
            var vehicle = new Bus();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsTrue(isTollFree);
        }

        [Test]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsDiplomat()
        {
            // Arrange
            var vehicleTollFeeStrategy = new VehicleTollFeeStrategyV2();
            var vehicle = new Diplomat();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsTrue(isTollFree);
        }

        [Test]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsMilitary()
        {
            // Arrange
            var vehicleTollFeeStrategy = new VehicleTollFeeStrategyV2();
            var vehicle = new Military();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsTrue(isTollFree);
        }

        [Test]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsForeign()
        {
            // Arrange
            var vehicleTollFeeStrategy = new VehicleTollFeeStrategyV2();
            var vehicle = new Foreign();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsTrue(isTollFree);
        }

        [Test]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsMotorcycle()
        {
            // Arrange
            var vehicleTollFeeStrategy = new VehicleTollFeeStrategyV2();
            var vehicle = new Motorcycle();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsTrue(isTollFree);
        }

        [Test]
        public void IsVehicleTollFree_ReturnsFalse_WhenVehicleIsCar()
        {
            // Arrange
            var vehicleTollFeeStrategy = new VehicleTollFeeStrategyV2();
            var vehicle = new Car();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsFalse(isTollFree);
        }

        [Test]
        public void IsVehicleTollFree_ReturnsFalse_WhenVehicleIsMotorbike()
        {
            // Arrange
            var vehicleTollFeeStrategy = new VehicleTollFeeStrategyV2();
            var vehicle = new Motorbike();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsFalse(isTollFree);
        }
    }
}