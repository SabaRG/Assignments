using congestion.calculator.v2.Application.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using congestion.calculator;
using congestion.calculator.v2.Application.Services;

namespace Congestion_Tax_Calculator_Net_Core_Tests_MSTest
{
    [TestClass]
    public class VehicleTollFeeStrategyV2Tests
    {
        public class Emergency : IVehicle
        {
            public string GetVehicleType()
            {
                return "Emergency";
            }
        }
        public class Diplomat : IVehicle
        {
            public string GetVehicleType()
            {
                return "Diplomat";
            }
        }
        public class Military : IVehicle
        {
            public string GetVehicleType()
            {
                return "Military";
            }
        }

        public class Foreign : IVehicle
        {
            public string GetVehicleType()
            {
                return "Foreign";
            }
        }

        public class Motorcycle : IVehicle
        {
            public string GetVehicleType()
            {
                return "Motorcycle";
            }
        }

        public class Bus : IVehicle
        {
            public string GetVehicleType()
            {
                return "Bus";
            }
        }

        VehicleTollFeeStrategyV2 vehicleTollFeeStrategy = new VehicleTollFeeStrategyV2();

        [TestMethod]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsEmergency()
        {
            // Arrange
            var vehicle = new Emergency();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsTrue(isTollFree);
        }

        [TestMethod]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsBus()
        {
            // Arrange
            var vehicle = new Bus();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsTrue(isTollFree);
        }

        [TestMethod]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsDiplomat()
        {
            // Arrange
            var vehicle = new Diplomat();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsTrue(isTollFree);
        }

        [TestMethod]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsMilitary()
        {
            // Arrange
            var vehicle = new Military();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsTrue(isTollFree);
        }

        [TestMethod]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsForeign()
        {
            // Arrange
            var vehicle = new Foreign();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsTrue(isTollFree);
        }

        [TestMethod]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsMotorcycle()
        {
            // Arrange
            var vehicle = new Motorcycle();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsTrue(isTollFree);
        }

        [TestMethod]
        public void IsVehicleTollFree_ReturnsFalse_WhenVehicleIsNull()
        {
            // Arrange
            Car vehicle = null;

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsFalse(isTollFree);
        }

        [TestMethod]
        public void IsVehicleTollFree_ReturnsFalse_WhenVehicleIsCar()
        {
            // Arrange
            var vehicle = new Car();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsFalse(isTollFree);
        }

        [TestMethod]
        public void IsVehicleTollFree_ReturnsFalse_WhenVehicleIsMotorbike()
        {
            // Arrange
            var vehicle = new Motorbike();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.IsFalse(isTollFree);
        }
    }
}