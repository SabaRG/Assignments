﻿using congestion.calculator.v2.Domain.Models;
using congestion.calculator.v2.Domain.ValueObjects;
using congestion.calculator.v2.Infrastructure.Providers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Xunit;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Infrastructure.Providers
{
    public class CSVTaxRuleRepositoryTests
    {
        public readonly static string sampleCSV_FilePath = "../../../../netcore/Rules-Template.csv";

        [Fact]
        public void GetAllRules_ReturnsCorrectRules_ForGothenburgCity()
        {
            // Arrange
            var city = "Gothenburg";
            var repository = new CSVTaxRuleRepository(sampleCSV_FilePath);

            // Act
            var result = repository.GetAllRules(city);

            // Assert
            var expected = new List<TaxRuleDTO>
            {
                new TaxRuleDTO { City = "Gothenburg", StarTime = new Time("06:00"), EndTime = new Time("06:29"), Fee = 8 },
                new TaxRuleDTO { City = "Gothenburg", StarTime = new Time("06:30"), EndTime = new Time("06:59"), Fee = 13 },
                new TaxRuleDTO { City = "Gothenburg", StarTime = new Time("07:00"), EndTime = new Time("07:59"), Fee = 18 },
                new TaxRuleDTO { City = "Gothenburg", StarTime = new Time("08:00"), EndTime = new Time("08:29"), Fee = 13 },
                new TaxRuleDTO { City = "Gothenburg", StarTime = new Time("08:30"), EndTime = new Time("14:59"), Fee = 8 },
                new TaxRuleDTO { City = "Gothenburg", StarTime = new Time("15:00"), EndTime = new Time("15:29"), Fee = 13 },
                new TaxRuleDTO { City = "Gothenburg", StarTime = new Time("15:30"), EndTime = new Time("16:59"), Fee = 18 },
                new TaxRuleDTO { City = "Gothenburg", StarTime = new Time("17:00"), EndTime = new Time("17:59"), Fee = 13 },
                new TaxRuleDTO { City = "Gothenburg", StarTime = new Time("18:00"), EndTime = new Time("18:29"), Fee = 8 },
                new TaxRuleDTO { City = "Gothenburg", StarTime = new Time("18:30"), EndTime = new Time("05:59"), Fee = 0 }
            };
            Assert.Equal(expected, result);
        }

        [Fact]
        public void GetAllRules_ReturnsCorrectRules_ForStockholmCity()
        {
            // Arrange
            var city = "Stockholm";
            var repository = new CSVTaxRuleRepository(sampleCSV_FilePath);

            // Act
            var result = repository.GetAllRules(city);

            // Assert
            var expected = new List<TaxRuleDTO>
            {
                new TaxRuleDTO { City = "Stockholm", StarTime = new Time("06:00"), EndTime = new Time("06:59"), Fee = 3 },
                new TaxRuleDTO { City = "Stockholm", StarTime = new Time("07:00"), EndTime = new Time("07:59"), Fee = 20 },
                new TaxRuleDTO { City = "Stockholm", StarTime = new Time("08:00"), EndTime = new Time("08:29"), Fee = 15 },
                new TaxRuleDTO { City = "Stockholm", StarTime = new Time("08:30"), EndTime = new Time("14:59"), Fee = 5 },
                new TaxRuleDTO { City = "Stockholm", StarTime = new Time("15:00"), EndTime = new Time("15:29"), Fee = 15 },
                new TaxRuleDTO { City = "Stockholm", StarTime = new Time("15:30"), EndTime = new Time("16:59"), Fee = 20 },
                new TaxRuleDTO { City = "Stockholm", StarTime = new Time("17:00"), EndTime = new Time("17:59"), Fee = 10 },
                new TaxRuleDTO { City = "Stockholm", StarTime = new Time("18:00"), EndTime = new Time("18:29"), Fee = 5 },
                new TaxRuleDTO { City = "Stockholm", StarTime = new Time("18:30"), EndTime = new Time("05:59"), Fee = 0 }
            };
            Assert.Equal(expected, result);
        }

        [Fact]
        public void GetAllRules_WrongFileAddress()
        {
            // Arrange
            var repository = new CSVTaxRuleRepository("tmp.tmp");

            // Act

            // Assert
            Assert.Throws<FileNotFoundException>(() => repository.GetAllRules("temp"));
        }
    }
}
