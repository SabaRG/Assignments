﻿using congestion.calculator.NetCore.Tests.xUnit.v2.Infrastructure.Providers;
using congestion.calculator.v2.Application.Services;
using congestion.calculator.v2.Domain.Models;
using congestion.calculator.v2.Domain.ValueObjects;
using congestion.calculator.v2.Infrastructure.Providers;
using congestion.calculator.v2.Infrastructure.Repositories;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Application.Services.IntegrationTests
{
    public class DateTollFeeStrategyV3IntegrationTests
    {
        private readonly ITaxRuleRepository _taxRuleRepository;
        private readonly DateTollFeeStrategyV3 _dateTollFeeStrategy;

        public DateTollFeeStrategyV3IntegrationTests()
        {
            _taxRuleRepository = new CSVTaxRuleRepository(CSVTaxRuleRepositoryTests.sampleCSV_FilePath);
            _dateTollFeeStrategy = new DateTollFeeStrategyV3(_taxRuleRepository, "Gothenburg");
        }

        [Fact]
        public void GetDateTollFee_ReturnsZero_WhenDateIsTollFree()
        {
            // Arrange
            var tollFreeDates = new List<DateTime>
            {
                new DateTime(2013, 1, 1, 10, 10, 10),
                new DateTime(2013, 1, 5, 10, 10, 10), // Saturday
                new DateTime(2013, 1, 6, 10, 10, 10), // Sunday
                new DateTime(2013, 3, 28, 10, 10, 10),
                new DateTime(2013, 4, 1, 10, 10, 10),
                new DateTime(2013, 5, 1, 10, 10, 10),
                new DateTime(2013, 6, 5, 10, 10, 10),
                new DateTime(2013, 7, 4, 10, 10, 10),
                new DateTime(2013, 11, 1, 10, 10, 10),
                new DateTime(2013, 12, 24, 10, 10, 10),
                new DateTime(2013, 12, 25, 10, 10, 10)
            };

            foreach (var tollFreeDate in tollFreeDates)
            {
                // Act
                var result = _dateTollFeeStrategy.GetDateTollFee(tollFreeDate);

                // Assert
                Assert.Equal(0, result);
            }
        }

        [Fact]
        public void GetDateTollFee_ThrowsInvalidOperationException_WhenNoAppropriateRuleExistsForDateAndCity()
        {
            // Arrange
            var date = new DateTime(2013, 8, 9, 10, 10, 10);

            var dateTollFeeStrategy = new DateTollFeeStrategyV3(_taxRuleRepository, "Other");

            // Act and Assert
            Assert.Throws<InvalidOperationException>(() => dateTollFeeStrategy.GetDateTollFee(date));
        }

        [Fact]
        [Trait("Category", "Skip")]
        [Trait("Reason", "This test is skipped because recently all dates is implemented and there is no out of range date.")]
        public void GetDateTollFee_ThrowsArgumentOutOfRangeException_WhenDateIsOutOf2013()
        {
            // Arrange
            var date = new DateTime(2023, 8, 9, 10, 10, 10);

            var dateTollFeeStrategy = new DateTollFeeStrategyV3(_taxRuleRepository, "Other");

            // Act and Assert
            Assert.Throws<InvalidOperationException>(() => dateTollFeeStrategy.GetDateTollFee(date));
        }


        [Fact]
        public void GetDateTollFee_ReturnsAppropriateFee_WhenAppropriateRuleExistsForDateAndCity()
        {
            // Arrange
            var date = new DateTime(2013, 7, 9, 7, 25, 14);

            // Act
            var result = _dateTollFeeStrategy.GetDateTollFee(date);

            // Assert
            Assert.Equal(0, result);
        }
    }
}
