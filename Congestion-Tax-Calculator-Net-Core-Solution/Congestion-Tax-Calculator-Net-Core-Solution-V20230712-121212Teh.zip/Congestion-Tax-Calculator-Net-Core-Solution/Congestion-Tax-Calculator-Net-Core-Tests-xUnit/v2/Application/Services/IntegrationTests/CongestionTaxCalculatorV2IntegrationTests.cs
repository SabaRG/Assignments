﻿using congestion.calculator;
using System;
using Xunit;
using System.Net.Http.Headers;
using congestion.calculator.v2.Application.Services;
using congestion.calculator.NetCore.Tests.xUnit.v2.Application.Services.UnitTests;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Application.Services.IntegrationTests
{
    public class CongestionTaxCalculatorV2IntegrationTestsForAllV2Strategies
    {
        readonly CongestionTaxCalculatorV2 calculator = new CongestionTaxCalculatorV2(
            new TollFeeStrategyV1(new VehicleTollFeeStrategyV2(), new DateTollFeeStrategyV2()));

        [Fact]
        public void GetTax_ReturnsZero_WhenNoDatesAreProvided()
        {
            // Arrange

            // Act
            var result = calculator.GetTax(new MockVehicle(), new DateTime[] { });

            // Assert
            Assert.Equal(0, result);
        }


        [Fact]
        public void GetTax_ReturnsCorrectTax_ForSingleHolidayDay()
        {
            // Arrange
            var vehicle = new MockVehicle();
            var dates = new DateTime[] { new DateTime(2013, 7, 7, 6, 30, 0),
                new DateTime(2013, 7, 7, 8, 30, 0),
                new DateTime(2013, 7, 7, 15, 0, 0) };

            // Act
            var result = calculator.GetTax(vehicle, dates);

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void GetTax_ReturnsCorrectTax_ForSingleNoneHolidayDay()
        {
            // Arrange
            var vehicle = new MockVehicle();
            var dates = new DateTime[] { new DateTime(2013, 8, 8, 6, 30, 0),
                new DateTime(2013, 8, 8, 8, 30, 0),
                new DateTime(2013, 8, 8, 15, 0, 0) };

            // Act
            var result = calculator.GetTax(vehicle, dates);

            // Assert
            Assert.Equal(34, result);
        }

        [Fact]
        public void GetTax_ReturnsCorrectTax_ForMultipleDays()
        {
            // Arrange
            var vehicle = new MockVehicle();
            var dates = new DateTime[] { new DateTime(2013, 8, 7, 6, 30, 0),
                new DateTime(2013, 8, 7, 8, 30, 0),
                new DateTime(2013, 8, 8, 15, 0, 0),
                new DateTime(2013, 8, 9, 9, 0, 0) };

            // Act
            var result = calculator.GetTax(vehicle, dates);

            // Assert
            Assert.Equal(42, result);
        }

        [Fact]
        public void GetTax_ReturnsMaximumTaxOf60_ForSingleDayWithHighFees()
        {
            // Arrange
            var vehicle = new MockVehicle();
            var dates = new DateTime[] { new DateTime(2013, 8, 7, 6, 30, 0),
                new DateTime(2013, 8, 7, 7, 31, 0),
                new DateTime(2013, 8, 7, 15, 30, 0) };

            // Act
            var result = calculator.GetTax(vehicle, dates);

            // Assert
            Assert.Equal(49, result);
        }

        [Fact]
        public void GetTax_ReturnsMaximumTaxOf60_ForSingleDayWithLessThan60MinutesInOut()
        {
            // Arrange
            var vehicle = new MockVehicle();
            var dates = new DateTime[] {
                new DateTime(2013, 8, 7, 6, 30, 0),
                new DateTime(2013, 8, 7, 6, 40, 0),
                new DateTime(2013, 8, 7, 7, 10, 0),
                new DateTime(2013, 8, 7, 8, 30, 0),
                new DateTime(2013, 8, 7, 15, 0, 0),
                new DateTime(2013, 8, 7, 19, 0, 0)
            };

            // Act
            var result = calculator.GetTax(vehicle, dates);

            // Assert
            Assert.Equal(39, result);
        }

        [Fact]
        public void GetTax_ReturnsMaximumTaxOf60_ForSingleDayWithLessThan60MinutesInOutWithHighFees()
        {
            // Arrange
            var vehicle = new MockVehicle();
            var dates = new DateTime[] {
                new DateTime(2013, 7, 7, 6, 30, 0),
                new DateTime(2013, 7, 7, 6, 40, 0),
                new DateTime(2013, 7, 7, 7, 10, 0),
                new DateTime(2013, 7, 7, 8, 30, 0),
                new DateTime(2013, 7, 7, 15, 0, 0),
                new DateTime(2013, 7, 7, 19, 0, 0)
            };
            var calculator2 = new CongestionTaxCalculatorV2(new MockHighFeeTollFeeCalculatorStrategy());

            // Act
            var result = calculator2.GetTax(vehicle, dates);

            // Assert
            Assert.Equal(60, result);
        }

        [Fact]
        public void GetTax_ReturnsMaximumTaxOf60_ForMultipleDaysWithHighFees()
        {
            // Arrange
            var vehicle = new MockVehicle();
            var dates = new DateTime[] {
                new DateTime(2013, 8, 7, 6, 0, 0),
                new DateTime(2013, 8, 9, 6, 0, 0),
                new DateTime(2013, 8, 9, 7, 1, 0),
                new DateTime(2013, 8, 9, 8, 2, 0),
                new DateTime(2013, 8, 9, 9, 3, 0),
                new DateTime(2013, 8, 9, 10, 4, 0),
                new DateTime(2013, 8, 9, 11, 5, 0),
                new DateTime(2013, 8, 9, 12, 6, 0),
                new DateTime(2013, 8, 9, 13, 7, 0),
                new DateTime(2013, 8, 9, 14, 8, 0),
                new DateTime(2013, 8, 11, 15, 0, 0), // Sunday
                new DateTime(2013, 8, 12, 15, 0, 0),
                new DateTime(2013, 8, 13, 19, 0, 0) // Out of working time
                 };

            // Act
            var result = calculator.GetTax(vehicle, dates);

            // Assert
            Assert.Equal(81, result);
        }
    }

    public class MockVehicle : IVehicle
    {
        public string GetVehicleType()
        {
            return "Car";
        }
    }
}