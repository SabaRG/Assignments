﻿using Moq;
using System;
using Xunit;
using congestion.calculator;
using congestion.calculator.v2.Application.Services;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Application.Services.UnitTests
{
    public class MainCongestionTaxCalculatorNewTests
    {
        private MockRepository mockRepository;

        public MainCongestionTaxCalculatorNewTests()
        {
            mockRepository = new MockRepository(MockBehavior.Strict);
        }

        [Fact]
        public void GetTaxBase_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { };

            // Act
            Assert.Throws<NullReferenceException>(() => MainCongestionTaxCalculatorNew.GetTaxV1Base(null, null));
            mockRepository.VerifyAll();
        }

        [Fact]
        public void GetTaxBase_ForFreeVehicleWithoNoDates()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { };

            // Act

            // Assert
            Assert.Throws<IndexOutOfRangeException>(() => MainCongestionTaxCalculatorNew.GetTaxV1Base(new Motorbike(), dates));
        }

        [Fact]
        public void GetTaxBase_ForFreeVehicle()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { new DateTime(2013, 1, 6) };

            // Act
            var result = MainCongestionTaxCalculatorNew.GetTaxV1Base(new Motorbike(), dates);

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void GetTaxV2_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { };

            // Act
            Assert.Throws<ArgumentNullException>(() => MainCongestionTaxCalculatorNew.GetTaxV2(null, null));
            mockRepository.VerifyAll();
        }

        [Fact]
        public void GetTaxV2_ForFreeVehicleWithoNoDates()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { };

            // Act
            var result = MainCongestionTaxCalculatorNew.GetTaxV2(new Motorbike(), dates);

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void GetTaxV2_ForFreeVehicle()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { new DateTime(2013, 1, 6) };

            // Act
            var result = MainCongestionTaxCalculatorNew.GetTaxV2(new Motorbike(), dates);

            // Assert
            Assert.Equal(0, result);
        }

        
        [Fact]
        public void GetTaxV3CSVFile_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { };

            // Act
            Assert.Throws<ArgumentNullException>(() => MainCongestionTaxCalculatorNew.GetTaxV3CSVFile(null, null));
            mockRepository.VerifyAll();
        }

        [Fact]
        public void GetTaxV3CSVFile_ForFreeVehicleWithoNoDates()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { };

            // Act
            var result = MainCongestionTaxCalculatorNew.GetTaxV3CSVFile(new Motorbike(), dates);

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void GetTaxV3CSVFile_ForFreeVehicle()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { new DateTime(2013, 1, 6) };

            // Act
            var result = MainCongestionTaxCalculatorNew.GetTaxV3CSVFile(new Motorbike(), dates);

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void GetTaxV3GothenburgFromCSVFile_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { };

            // Act
            Assert.Throws<ArgumentNullException>(() => MainCongestionTaxCalculatorNew.GetTaxV3GothenburgFromCSVFile(null, null));
            mockRepository.VerifyAll();
        }

        [Fact]
        public void GetTaxV3GothenburgFromCSVFile_ForFreeVehicleWithoNoDates()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { };

            // Act
            var result = MainCongestionTaxCalculatorNew.GetTaxV3GothenburgFromCSVFile(new Motorbike(), dates);

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void GetTaxV3GothenburgFromCSVFile_ForFreeVehicle()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { new DateTime(2013, 1, 6) };

            // Act
            var result = MainCongestionTaxCalculatorNew.GetTaxV3GothenburgFromCSVFile(new Motorbike(), dates);

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void GetTaxV3GothenburgFromMDFile_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { };

            // Act
            Assert.Throws<ArgumentNullException>(() => MainCongestionTaxCalculatorNew.GetTaxV3GothenburgFromMDFile(null, null));
            mockRepository.VerifyAll();
        }

        [Fact]
        public void GetTaxV3GothenburgFromMDFile_ForFreeVehicleWithoNoDates()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { };

            // Act
            var result = MainCongestionTaxCalculatorNew.GetTaxV3GothenburgFromMDFile(new Motorbike(), dates);

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void GetTaxV3GothenburgFromMDFile_ForFreeVehicle()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { new DateTime(2013, 1, 6) };

            // Act
            var result = MainCongestionTaxCalculatorNew.GetTaxV3GothenburgFromMDFile(new Motorbike(), dates);

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void GetTaxV3MDFile_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { };

            // Act
            Assert.Throws<ArgumentNullException>(() => MainCongestionTaxCalculatorNew.GetTaxV3MDFile(null, null));
            mockRepository.VerifyAll();
        }

        [Fact]
        public void GetTaxV3MDFile_ForFreeVehicleWithoNoDates()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { };

            // Act
            var result = MainCongestionTaxCalculatorNew.GetTaxV3MDFile(new Motorbike(), dates);

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void GetTaxV3MDFile_ForFreeVehicle()
        {
            // Arrange
            IVehicle vehicle = null;
            var dates = new DateTime[] { new DateTime(2013, 1, 6) };

            // Act
            var result = MainCongestionTaxCalculatorNew.GetTaxV3MDFile(new Motorbike(), dates);

            // Assert
            Assert.Equal(0, result);
        }
    }
}
