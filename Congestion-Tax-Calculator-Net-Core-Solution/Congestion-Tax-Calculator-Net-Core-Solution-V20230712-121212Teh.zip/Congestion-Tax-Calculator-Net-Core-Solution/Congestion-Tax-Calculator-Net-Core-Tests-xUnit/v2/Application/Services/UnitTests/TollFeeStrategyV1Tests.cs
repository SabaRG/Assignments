﻿using Moq;
using System;
using Xunit;
using congestion.calculator;
using congestion.calculator.v2.Application.Services.Interfaces;
using congestion.calculator.v2.Application.Services;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Application.Services.UnitTests
{
    public class TollFeeStrategyV2Tests
    {
        private MockRepository mockRepository;

        private Mock<IVehicleTollFeeStrategy> mockVehicleTollFeeStrategy;
        private Mock<IDateTollFeeStrategy> mockDateTollFeeStrategy;

        public TollFeeStrategyV2Tests()
        {
            mockRepository = new MockRepository(MockBehavior.Strict);

            mockVehicleTollFeeStrategy = mockRepository.Create<IVehicleTollFeeStrategy>();
            mockDateTollFeeStrategy = mockRepository.Create<IDateTollFeeStrategy>();
        }

        private TollFeeStrategyV1 CreateTollFeeStrategyV1()
        {
            return new TollFeeStrategyV1(
                mockVehicleTollFeeStrategy.Object,
                mockDateTollFeeStrategy.Object);
        }

        [Fact]
        public void GetTollFee_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var tollFeeStrategyV1 = CreateTollFeeStrategyV1();
            IVehicle vehicle = null;
            DateTime date = default;
            mockVehicleTollFeeStrategy.Setup(x => x.IsVehicleTollFree(null)).Returns(false);
            mockDateTollFeeStrategy.Setup(x => x.GetDateTollFee(date)).Returns(10);
            // Act
            var result = tollFeeStrategyV1.GetTollFee(
                vehicle,
                date);

            // Assert
            Assert.Equal(10, result);
            mockRepository.VerifyAll();
        }

        [Fact]
        public void GetTollFee_ReturnsZero_WhenVehicleIsTollFree()
        {
            // Arrange
            var tollFeeStrategyV1 = CreateTollFeeStrategyV1();
            var mockVehicle = new Mock<IVehicle>();
            var date = new DateTime(2023, 7, 9);
            mockVehicleTollFeeStrategy.Setup(x => x.IsVehicleTollFree(mockVehicle.Object)).Returns(true);

            // Act
            var result = tollFeeStrategyV1.GetTollFee(mockVehicle.Object, date);

            // Assert
            Assert.Equal(0, result);
            mockRepository.VerifyAll();
        }
    }
}
