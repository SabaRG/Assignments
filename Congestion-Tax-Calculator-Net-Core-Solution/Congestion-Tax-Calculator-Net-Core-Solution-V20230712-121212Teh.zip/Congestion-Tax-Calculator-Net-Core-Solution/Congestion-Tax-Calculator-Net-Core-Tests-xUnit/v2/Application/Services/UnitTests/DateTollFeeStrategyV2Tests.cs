﻿using System;
using Xunit;
using System.Collections.Generic;
using congestion.calculator.v2.Application.Services;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Application.Services.UnitTests
{
    public class DateTollFeeStrategyV2Tests
    {
        [Fact]
        public void GetDateTollFee_ReturnsZero_WhenDateIsTollFree()
        {
            // Arrange
            var dateTollFeeStrategy = new DateTollFeeStrategyV2();
            var tollFreeDates = GetAllTollFreeDates();

            foreach (var tollFreeDate in tollFreeDates)
            {
                // Act
                var tollFeeOfBeforeDayOfHoliday = dateTollFeeStrategy.GetDateTollFee(tollFreeDate.AddDays(-1)); // to check the before day of every Holiday
                var tollFeeOfHoliday = dateTollFeeStrategy.GetDateTollFee(tollFreeDate);

                // Assert
                Assert.Equal(0, tollFeeOfBeforeDayOfHoliday);
                Assert.Equal(0, tollFeeOfHoliday);
            }
        }

        private static List<DateTime> GetAllTollFreeDates()
        {
            var tollFreeDates = new List<DateTime>();

            // New Year's Day
            tollFreeDates.Add(new DateTime(2013, 1, 1));

            // TODO: Code Review 39: [Need Team Agreement] Is this ChatGPT test case generated date really a holiday?
            // It seems some other generated dates are not considered in my code are was not in the callendar of commented URL
            // above the `IsTollFreeDate` method.
            // Epiphany
            tollFreeDates.Add(new DateTime(2013, 1, 6));

            // Maundy Thursday
            tollFreeDates.Add(new DateTime(2013, 3, 28));

            // Good Friday
            tollFreeDates.Add(new DateTime(2013, 3, 29));

            // Easter Day
            tollFreeDates.Add(new DateTime(2013, 3, 31));

            // Easter Monday
            tollFreeDates.Add(new DateTime(2013, 4, 1));

            // Ascension Day
            tollFreeDates.Add(new DateTime(2013, 5, 9));

            // Whit Sunday
            tollFreeDates.Add(new DateTime(2013, 5, 19));

            // National Day
            tollFreeDates.Add(new DateTime(2013, 6, 6));

            // Midsummer Eve
            tollFreeDates.Add(new DateTime(2013, 6, 21));

            // Midsummer Day
            tollFreeDates.Add(new DateTime(2013, 6, 22));

            // All Saints' Day
            tollFreeDates.Add(new DateTime(2013, 11, 2));

            // Christmas Eve
            tollFreeDates.Add(new DateTime(2013, 12, 24));

            // Christmas Day
            tollFreeDates.Add(new DateTime(2013, 12, 25));

            // Boxing Day
            tollFreeDates.Add(new DateTime(2013, 12, 26));

            return tollFreeDates;
        }

        [Fact]
        public void GetDateTollFee_ReturnsEight_WhenDateIsBetween6_00_And6_30()
        {
            // Arrange
            var dateTollFeeStrategy = new DateTollFeeStrategyV2();
            var minDate = new DateTime(2013, 1, 10, 6, 0, 0);
            var midDate = new DateTime(2013, 1, 10, 6, 15, 0);
            var maxDate = new DateTime(2013, 1, 10, 6, 29, 0);

            // Act
            var minTollFee = dateTollFeeStrategy.GetDateTollFee(minDate);
            var midTollFee = dateTollFeeStrategy.GetDateTollFee(midDate);
            var maxTollFee = dateTollFeeStrategy.GetDateTollFee(maxDate);

            // Assert
            Assert.Equal(8, minTollFee);
            Assert.Equal(8, midTollFee);
            Assert.Equal(8, maxTollFee);
        }

        [Fact]
        public void GetDateTollFee_ReturnsThirteen_WhenDateIsBetween6_30_And7_00()
        {
            // Arrange
            var dateTollFeeStrategy = new DateTollFeeStrategyV2();
            var minDate = new DateTime(2013, 1, 10, 6, 30, 0);
            var midDate = new DateTime(2013, 1, 10, 6, 45, 0);
            var maxDate = new DateTime(2013, 1, 10, 6, 59, 0);

            // Act
            var minTollFee = dateTollFeeStrategy.GetDateTollFee(minDate);
            var midTollFee = dateTollFeeStrategy.GetDateTollFee(midDate);
            var maxTollFee = dateTollFeeStrategy.GetDateTollFee(maxDate);

            // Assert
            Assert.Equal(13, minTollFee);
            Assert.Equal(13, midTollFee);
            Assert.Equal(13, maxTollFee);
        }

        [Fact]
        public void GetDateTollFee_ReturnsEighteen_WhenDateIsBetween7_00_And8_00()
        {
            // Arrange
            var dateTollFeeStrategy = new DateTollFeeStrategyV2();
            var minDate = new DateTime(2013, 1, 10, 7, 0, 0);
            var midDate = new DateTime(2013, 1, 10, 7, 30, 0);
            var maxDate = new DateTime(2013, 1, 10, 7, 59, 0);

            // Act
            var minTollFee = dateTollFeeStrategy.GetDateTollFee(minDate);
            var midTollFee = dateTollFeeStrategy.GetDateTollFee(midDate);
            var maxTollFee = dateTollFeeStrategy.GetDateTollFee(maxDate);

            // Assert
            Assert.Equal(18, minTollFee);
            Assert.Equal(18, midTollFee);
            Assert.Equal(18, maxTollFee);
        }

        [Fact]
        public void GetDateTollFee_ReturnsThirteen_WhenDateIsBetween8_00_And8_30()
        {
            // Arrange
            var dateTollFeeStrategy = new DateTollFeeStrategyV2();
            var minDate = new DateTime(2013, 1, 10, 8, 0, 0);
            var midDate = new DateTime(2013, 1, 10, 8, 15, 0);
            var maxDate = new DateTime(2013, 1, 10, 8, 29, 0);

            // Act
            var minTollFee = dateTollFeeStrategy.GetDateTollFee(minDate);
            var midTollFee = dateTollFeeStrategy.GetDateTollFee(midDate);
            var maxTollFee = dateTollFeeStrategy.GetDateTollFee(maxDate);

            // Assert
            Assert.Equal(13, minTollFee);
            Assert.Equal(13, midTollFee);
            Assert.Equal(13, maxTollFee);
        }

        [Fact]
        public void GetDateTollFee_ReturnsEight_WhenDateIsBetween8_30_And14_59()
        {
            // Arrange
            var dateTollFeeStrategy = new DateTollFeeStrategyV2();
            var dates = new[]{
                new DateTime(2013, 1, 10, 8, 30, 0),
                new DateTime(2013, 1, 10, 8, 59, 0),
                new DateTime(2013, 1, 10, 9, 0, 0),
                new DateTime(2013, 1, 10, 11, 0, 0),
                new DateTime(2013, 1, 10, 13, 30, 0),
                new DateTime(2013, 1, 10, 14, 0, 0),
                new DateTime(2013, 1, 10, 14, 59, 0)
            };

            foreach (var date in dates)
            {
                // Act
                var TollFee = dateTollFeeStrategy.GetDateTollFee(date);

                // Assert
                Assert.Equal(8, TollFee);
            }
        }

        [Fact]
        public void GetDateTollFee_ReturnsThirteen_WhenDateIsBetween15_00_And15_29()
        {
            // Arrange
            var dateTollFeeStrategy = new DateTollFeeStrategyV2();
            var minDate = new DateTime(2013, 1, 10, 15, 0, 0);
            var midDate = new DateTime(2013, 1, 10, 15, 15, 0);
            var maxDate = new DateTime(2013, 1, 10, 15, 29, 0);

            // Act
            var minTollFee = dateTollFeeStrategy.GetDateTollFee(minDate);
            var midTollFee = dateTollFeeStrategy.GetDateTollFee(midDate);
            var maxTollFee = dateTollFeeStrategy.GetDateTollFee(maxDate);

            // Assert
            Assert.Equal(13, minTollFee);
            Assert.Equal(13, midTollFee);
            Assert.Equal(13, maxTollFee);
        }

        [Fact]
        public void GetDateTollFee_ReturnsThirteen_WhenDateIsBetween15_30_And16_59()
        {
            // Arrange
            var dateTollFeeStrategy = new DateTollFeeStrategyV2();
            var dates = new[]{
                new DateTime(2013, 1, 10, 15, 30, 0),
                new DateTime(2013, 1, 10, 15, 59, 0),
                new DateTime(2013, 1, 10, 16, 0, 0),
                new DateTime(2013, 1, 10, 16, 15, 0),
                new DateTime(2013, 1, 10, 16, 59, 0)
            };

            foreach (var date in dates)
            {
                // Act
                var TollFee = dateTollFeeStrategy.GetDateTollFee(date);

                // Assert
                Assert.Equal(18, TollFee);
            }
        }

        [Fact]
        public void GetDateTollFee_ReturnsEighteen_WhenDateIsBetween17_00_And17_59()
        {
            // Arrange
            var dateTollFeeStrategy = new DateTollFeeStrategyV2();
            var minDate = new DateTime(2013, 1, 10, 17, 0, 0);
            var midDate = new DateTime(2013, 1, 10, 17, 30, 0);
            var maxDate = new DateTime(2013, 1, 10, 17, 59, 0);

            // Act
            var minTollFee = dateTollFeeStrategy.GetDateTollFee(minDate);
            var midTollFee = dateTollFeeStrategy.GetDateTollFee(midDate);
            var maxTollFee = dateTollFeeStrategy.GetDateTollFee(maxDate);

            // Assert
            Assert.Equal(13, minTollFee);
            Assert.Equal(13, midTollFee);
            Assert.Equal(13, maxTollFee);
        }

        [Fact]
        public void GetDateTollFee_ReturnsThirteen_WhenDateIsBetween18_00_to_18_29()
        {
            // Arrange
            var dateTollFeeStrategy = new DateTollFeeStrategyV2();
            var minDate = new DateTime(2013, 1, 10, 18, 0, 0);
            var midDate = new DateTime(2013, 1, 10, 18, 15, 0);
            var maxDate = new DateTime(2013, 1, 10, 18, 29, 0);

            // Act
            var minTollFee = dateTollFeeStrategy.GetDateTollFee(minDate);
            var midTollFee = dateTollFeeStrategy.GetDateTollFee(midDate);
            var maxTollFee = dateTollFeeStrategy.GetDateTollFee(maxDate);

            // Assert
            Assert.Equal(8, minTollFee);
            Assert.Equal(8, midTollFee);
            Assert.Equal(8, maxTollFee);
        }

        [Fact]
        public void GetDateTollFee_ReturnsEight_WhenDateIsBetween18_30_to_05_59()
        {
            // Arrange
            var dateTollFeeStrategy = new DateTollFeeStrategyV2();
            var dates = new[]{
                new DateTime(2013, 1, 10, 18, 30, 0),
                new DateTime(2013, 1, 10, 18, 59, 0),
                new DateTime(2013, 1, 10, 19, 0, 0),
                new DateTime(2013, 1, 10, 19, 59, 0),
                new DateTime(2013, 1, 10, 23, 0, 0),
                new DateTime(2013, 1, 10, 23, 59, 0),
                new DateTime(2013, 1, 10, 0, 0, 0),
                new DateTime(2013, 1, 10, 0, 59, 0),
                new DateTime(2013, 1, 10, 5, 0, 0),
                new DateTime(2013, 1, 10, 5, 30, 0),
                new DateTime(2013, 1, 10, 5, 59, 0)
            };

            foreach (var date in dates)
            {
                // Act
                var TollFee = dateTollFeeStrategy.GetDateTollFee(date);

                // Assert
                Assert.Equal(0, TollFee);
            }
        }

        [Fact]
        public void GetDateTollFee_ThrowsArgumentOutOfRangeException_WhenDateHasInvalidHour()
        {
            // Arrange
            var dateTollFeeStrategy = new DateTollFeeStrategyV2();
            DateTime invalidDate;

            // Act & Assert
            Assert.Throws<ArgumentOutOfRangeException>(() => { invalidDate = new DateTime(2013, 1, 2, 25, 0, 0); });
            //Assert.Throws<ArgumentOutOfRangeException>(() => dateTollFeeStrategy.GetDateTollFee(invalidDate));
        }

        [Fact]
        public void GetDateTollFee_ThrowsArgumentOutOfRangeException_WhenDateHasInvalidMinute()
        {
            // Arrange
            var dateTollFeeStrategy = new DateTollFeeStrategyV2();
            DateTime invalidDate;

            // Act & Assert
            Assert.Throws<ArgumentOutOfRangeException>(() => { invalidDate = new DateTime(2013, 1, 2, 10, 60, 0); });
            //Assert.Throws<ArgumentOutOfRangeException>(() => dateTollFeeStrategy.GetDateTollFee(invalidDate));
        }
    }
}