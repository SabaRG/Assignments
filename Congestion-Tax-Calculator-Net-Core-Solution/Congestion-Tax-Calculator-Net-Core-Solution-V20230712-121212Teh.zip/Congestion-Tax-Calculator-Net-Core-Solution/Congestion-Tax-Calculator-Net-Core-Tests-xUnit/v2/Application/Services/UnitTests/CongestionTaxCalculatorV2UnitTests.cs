﻿using congestion.calculator;
using System;
using Xunit;
using congestion.calculator.v2.Application.Services.Interfaces;
using congestion.calculator.v2.Application.Services;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Application.Services.UnitTests
{
    public class CongestionTaxCalculatorV2UnitTests
    {
        [Fact]
        public void GetTax_ReturnsZero_WhenNoDatesAreProvided()
        {
            // Arrange
            var calculator = new CongestionTaxCalculatorV2(new MockTollFeeCalculatorStrategy());

            // Act
            var result = calculator.GetTax(new MockVehicle(), new DateTime[] { });

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void GetTax_ReturnsCorrectTax_ForSingleDay()
        {
            // NoneHoliday
            // Arrange
            var vehicle = new MockVehicle();
            var dates = new DateTime[] { new DateTime(2013, 7, 7, 6, 30, 0),
                new DateTime(2013, 7, 7, 8, 30, 0),
                new DateTime(2013, 7, 7, 15, 0, 0) };
            var calculator = new CongestionTaxCalculatorV2(new MockTollFeeCalculatorStrategy());

            // Act
            var result = calculator.GetTax(vehicle, dates);

            // Assert
            Assert.Equal(30, result);
        }

        [Fact]
        public void GetTax_ReturnsCorrectTax_ForMultipleDays()
        {
            // Arrange
            var vehicle = new MockVehicle();
            var dates = new DateTime[] { new DateTime(2013, 7, 7, 6, 30, 0),
                new DateTime(2013, 7, 7, 8, 30, 0),
                new DateTime(2013, 7, 8, 15, 0, 0),
                new DateTime(2013, 7, 9, 9, 0, 0) };
            var calculator = new CongestionTaxCalculatorV2(new MockTollFeeCalculatorStrategy());

            // Act
            var result = calculator.GetTax(vehicle, dates);

            // Assert
            Assert.Equal(40, result);
        }

        [Fact]
        public void GetTax_ReturnsMaximumTaxOf60_ForSingleDayWithHighFees()
        {
            // Arrange
            var vehicle = new MockVehicle();
            var dates = new DateTime[] {
                new DateTime(2013, 7, 7, 6, 30, 0),
                new DateTime(2013, 7, 7, 8, 30, 0),
                new DateTime(2013, 7, 7, 15, 0, 0)
            };
            var calculator = new CongestionTaxCalculatorV2(new MockHighFeeTollFeeCalculatorStrategy());

            // Act
            var result = calculator.GetTax(vehicle, dates);

            // Assert
            Assert.Equal(60, result);
        }


        [Fact]
        public void GetTax_ReturnsMaximumTaxOf60_ForSingleDayWithLessThan60MinutesInOut()
        {
            // Arrange
            var vehicle = new MockVehicle();
            var dates = new DateTime[] {
                new DateTime(2013, 7, 7, 6, 30, 0),
                new DateTime(2013, 7, 7, 6, 40, 0),
                new DateTime(2013, 7, 7, 7, 10, 0),
                new DateTime(2013, 7, 7, 8, 30, 0),
                new DateTime(2013, 7, 7, 15, 0, 0)
            };
            var calculator = new CongestionTaxCalculatorV2(new MockHighFeeTollFeeCalculatorStrategy());

            // Act
            var result = calculator.GetTax(vehicle, dates);

            // Assert
            Assert.Equal(60, result);
        }

        [Fact]
        public void GetTax_ReturnsMaximumTaxOf60_ForMultipleDaysWithHighFees()
        {
            // Arrange
            var vehicle = new MockVehicle();
            var dates = new DateTime[] {
                new DateTime(2013, 7, 7, 6, 30, 0),
                new DateTime(2013, 7, 7, 8, 30, 0),
                new DateTime(2013, 7, 8, 15, 0, 0),
                new DateTime(2013, 7, 9, 9, 0, 0)
            };
            var calculator = new CongestionTaxCalculatorV2(new MockHighFeeTollFeeCalculatorStrategy());

            // Act
            var result = calculator.GetTax(vehicle, dates);

            // Assert
            Assert.Equal(80, result);
        }
    }

    public class MockVehicle : IVehicle
    {
        public string GetVehicleType()
        {
            return "Car";
        }
    }

    public class MockTollFeeCalculatorStrategy : ITollFeeCalculatorStrategy
    {
        public int GetTollFee(IVehicle vehicle, DateTime date)
        {
            return 10;
        }
    }

    public class MockHighFeeTollFeeCalculatorStrategy : ITollFeeCalculatorStrategy
    {
        Random r = new Random();

        public int GetTollFee(IVehicle vehicle, DateTime date)
        {
            //return r.Next(10, 15);
            return 20;
        }
    }
}