﻿using System;
using Xunit;
using congestion.calculator;
using congestion.calculator.v2.Application.Services;
using static congestion.calculator.NetCore.Tests.xUnit.v2.Application.Services.Interfaces.ITollFeeCalculatorTests;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Application.Services.UnitTests
{

    public class VehicleTollFeeStrategyV2Tests
    {
        public class Emergency : IVehicle
        {
            public string GetVehicleType()
            {
                return "Emergency";
            }
        }
        public class Diplomat : IVehicle
        {
            public string GetVehicleType()
            {
                return "Diplomat";
            }
        }
        public class Military : IVehicle
        {
            public string GetVehicleType()
            {
                return "Military";
            }
        }

        public class Foreign : IVehicle
        {
            public string GetVehicleType()
            {
                return "Foreign";
            }
        }

        public class Motorcycle : IVehicle
        {
            public string GetVehicleType()
            {
                return "Motorcycle";
            }
        }

        VehicleTollFeeStrategyV2 vehicleTollFeeStrategy = new VehicleTollFeeStrategyV2();


        [Fact]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsEmergency()
        {
            // Arrange
            var vehicle = new Emergency();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.True(isTollFree);
        }

        [Fact]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsBus()
        {
            // Arrange
            var vehicle = new Bus();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.True(isTollFree);
        }

        [Fact]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsDiplomat()
        {
            // Arrange
            var vehicle = new Diplomat();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.True(isTollFree);
        }

        [Fact]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsMilitary()
        {
            // Arrange
            var vehicle = new Military();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.True(isTollFree);
        }

        [Fact]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsForeign()
        {
            // Arrange
            var vehicle = new Foreign();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.True(isTollFree);
        }

        [Fact]
        public void IsVehicleTollFree_ReturnsTrue_WhenVehicleIsMotorcycle()
        {
            // Arrange
            var vehicle = new Motorcycle();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.True(isTollFree);
        }

        [Fact]
        public void IsVehicleTollFree_ReturnsFalse_WhenVehicleIsCar()
        {
            // Arrange
            var vehicle = new Car();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.False(isTollFree);
        }

        [Fact]
        public void IsVehicleTollFree_ReturnsFalse_WhenVehicleIsMotorbike()
        {
            // Arrange
            var vehicle = new Motorbike();

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.False(isTollFree);
        }
        
        [Fact]
        public void IsVehicleTollFree_ReturnsFalse_WhenVehicleIsNull()
        {
            // Arrange
            Car vehicle = null;

            // Act
            var isTollFree = vehicleTollFeeStrategy.IsVehicleTollFree(vehicle);

            // Assert
            Assert.False(isTollFree);
        }
    }
}
