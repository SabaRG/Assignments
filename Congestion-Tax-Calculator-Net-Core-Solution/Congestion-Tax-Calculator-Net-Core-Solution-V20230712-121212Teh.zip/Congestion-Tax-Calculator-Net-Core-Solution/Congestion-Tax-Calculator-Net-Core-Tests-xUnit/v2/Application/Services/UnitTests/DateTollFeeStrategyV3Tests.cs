﻿using congestion.calculator.v2.Application.Services;
using congestion.calculator.v2.Domain.Models;
using congestion.calculator.v2.Domain.ValueObjects;
using congestion.calculator.v2.Infrastructure.Repositories;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Application.Services.UnitTests
{
    public class DateTollFeeStrategyV3Tests
    {
        private readonly Mock<ITaxRuleRepository> _mockTaxRuleRepo;
        private readonly DateTollFeeStrategyV3 _dateTollFeeStrategy;

        public DateTollFeeStrategyV3Tests()
        {
            _mockTaxRuleRepo = new Mock<ITaxRuleRepository>();
            _dateTollFeeStrategy = new DateTollFeeStrategyV3(_mockTaxRuleRepo.Object, "TestCity");
        }

        [Fact]
        public void GetDateTollFee_ReturnsZero_WhenDateIsTollFree()
        {
            // Arrange
            var tollFreeDates = new List<DateTime>
            {
                new DateTime(2013, 1, 1, 10, 10, 10),   // holiday
                new DateTime(2013, 1, 5, 10, 10, 10),   // Saturday
                new DateTime(2013, 1, 6, 10, 10, 10),   // Sunday
                new DateTime(2013, 3, 28, 10, 10, 10),
                new DateTime(2013, 3, 29, 10, 10, 10),
                new DateTime(2013, 7, 4, 10, 10, 10),
                new DateTime(2013, 11, 1, 10, 10, 10),
                new DateTime(2013, 12, 24, 10, 10, 10),
                new DateTime(2013, 12, 25, 10, 10, 10)
            };

            foreach (var tollFreeDate in tollFreeDates)
            {
                // Act
                var result = _dateTollFeeStrategy.GetDateTollFee(tollFreeDate);

                // Assert
                Assert.Equal(0, result);
            }
        }

        [Fact]
        public void GetDateTollFee_ThrowsInvalidOperationException_WhenNoAppropriateRuleExistsForDateAndCity()
        {
            // Arrange
            var date = new DateTime(2013, 8, 9, 10, 10, 10);
            _mockTaxRuleRepo.Setup(repo => repo.GetAllRules("TestCity")).Returns(new List<TaxRuleDTO>());

            // Act and Assert
            Assert.Throws<InvalidOperationException>(() => _dateTollFeeStrategy.GetDateTollFee(date));
        }

        [Fact]
        public void GetDateTollFee_ReturnsAppropriateFee_WhenAppropriateRuleExistsForDateAndCity()
        {
            // Arrange
            var date = new DateTime(2013, 8, 9, 7, 25, 14);
            var taxRules = new List<TaxRuleDTO>
            {
                new TaxRuleDTO
                {
                    StarTime = new Time(6, 0, 0),
                    EndTime = new Time (7, 0, 0),
                    Fee = 10
                },
                new TaxRuleDTO
                {
                    StarTime = new Time (7, 0, 0),
                    EndTime = new Time (8, 0, 0),
                    Fee = 20
                }
            };
            _mockTaxRuleRepo.Setup(repo => repo.GetAllRules("TestCity")).Returns(taxRules);

            // Act
            var result = _dateTollFeeStrategy.GetDateTollFee(date);

            // Assert
            Assert.Equal(20, result);
        }
    }
}
