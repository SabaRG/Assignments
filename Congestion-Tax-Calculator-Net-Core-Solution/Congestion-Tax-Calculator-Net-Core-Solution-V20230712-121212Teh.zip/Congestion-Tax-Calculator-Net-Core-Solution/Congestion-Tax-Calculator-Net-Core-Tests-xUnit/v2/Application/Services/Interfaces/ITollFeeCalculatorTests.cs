﻿using System;
using Xunit;
using Moq;
using congestion.calculator;
using congestion.calculator.v2.Application.Services.Interfaces;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Application.Services.Interfaces
{
    public class ITollFeeCalculatorTests
    {
        public class Bus : IVehicle
        {
            public string GetVehicleType()
            {
                return "Bus";
            }
        }

        [Fact]
        public void GetTollFee_ReturnsZero_WhenVehicleIsTollFree()
        {
            // Arrange
            var tollFeeCalculatorMock = new Mock<ITollFeeCalculatorStrategy>();
            tollFeeCalculatorMock.Setup(x => x.GetTollFee(It.IsAny<IVehicle>(), It.IsAny<DateTime>())).Returns(0);
            var tollFeeCalculator = tollFeeCalculatorMock.Object;
            var vehicle = new Car(); // Assuming Car is toll-free by default
            var date = new DateTime(2013, 1, 1);

            // Act
            var tollFee = tollFeeCalculator.GetTollFee(vehicle, date);

            // Assert
            Assert.Equal(0, tollFee);
        }

        [Fact]
        public void GetTollFee_ReturnsCorrectFee_WhenVehicleIsNotTollFree()
        {
            // Arrange
            var tollFeeCalculatorMock = new Mock<ITollFeeCalculatorStrategy>();
            tollFeeCalculatorMock.Setup(x => x.GetTollFee(It.IsAny<IVehicle>(), It.IsAny<DateTime>())).Returns(10);
            var tollFeeCalculator = tollFeeCalculatorMock.Object;
            var vehicle = new Car(); // Assuming Car is not toll-free on weekends
            var date = new DateTime(2013, 1, 2); // Sunday

            // Act
            var tollFee = tollFeeCalculator.GetTollFee(vehicle, date);

            // Assert
            Assert.Equal(10, tollFee);
        }

        [Fact]
        public void GetTollFee_ReturnsMaxValue_WhenTollFeeExceedsMaxValue()
        {
            // Arrange
            var tollFeeCalculatorMock = new Mock<ITollFeeCalculatorStrategy>();
            tollFeeCalculatorMock.Setup(x => x.GetTollFee(It.IsAny<IVehicle>(), It.IsAny<DateTime>())).Returns(int.MaxValue);
            var tollFeeCalculator = tollFeeCalculatorMock.Object;
            var vehicle = new Bus(); // Assuming Bus has a toll fee of 100 on every day
            var date = new DateTime(2013, 1, 1);

            // Act
            var tollFee = tollFeeCalculator.GetTollFee(vehicle, date);

            // Assert
            Assert.Equal(int.MaxValue, tollFee);
        }
    }
}