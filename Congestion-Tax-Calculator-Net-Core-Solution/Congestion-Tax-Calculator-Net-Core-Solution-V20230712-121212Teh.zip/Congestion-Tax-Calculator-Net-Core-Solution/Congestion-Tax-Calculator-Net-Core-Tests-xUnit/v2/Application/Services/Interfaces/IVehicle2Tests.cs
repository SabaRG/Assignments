﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using congestion.calculator.v2.Application.Services.Interfaces;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Application.Services.Interfaces
{
    public class IVehicle2Tests
    {
        private class Car : IVehicleV2 { }
        private class Truck : IVehicleV2 { }

        [Fact]
        public void GetVehicleType_ReturnsCorrectTypeForCar()
        {
            // Arrange
            IVehicleV2 car = new Car();

            // Act
            var result = car.GetVehicleType();

            // Assert
            Assert.Equal("Car", result);
        }

        [Fact]
        public void GetVehicleType_ReturnsCorrectTypeForTruck()
        {
            // Arrange
            IVehicleV2 truck = new Truck();

            // Act
            var result = truck.GetVehicleType();

            // Assert
            Assert.Equal("Truck", result);
        }
    }
}
