﻿using System;
using System.Collections.Generic;
using System.Text;
using static congestion.calculator.v2.Application.Services.Utility.SwedishHolidayService;
using Xunit;
using congestion.calculator.v2.Application.Services.Utility;
using Microsoft.VisualStudio.TestPlatform.TestHost;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Application.Services
{
    public class SwedenHolidayServiceTests
    {
        [Theory]
        [InlineData("2013-01-01", HolidayType.Public, true)]
        [InlineData("2013-04-01", HolidayType.Public, true)]
        [InlineData("2013-05-18", HolidayType.CommonLocal, true)]
        [InlineData("2013-11-10", HolidayType.TypicalNonWorking, true)]
        [InlineData("2013-07-11", HolidayType.Public, false)]
        [InlineData("2013-07-11", HolidayType.CommonLocal, false)]
        [InlineData("2013-07-11", HolidayType.TypicalNonWorking, false)]
        [InlineData("2023-01-01", HolidayType.Public, true)]
        [InlineData("2023-06-06", HolidayType.Public, true)]
        [InlineData("2023-06-24", HolidayType.Public, true)]
        [InlineData("2023-11-04", HolidayType.Public, true)]
        [InlineData("2023-12-25", HolidayType.Public | HolidayType.TypicalNonWorking, true)]
        [InlineData("2023-12-26", HolidayType.Public | HolidayType.TypicalNonWorking, true)]
        [InlineData("2023-07-11", HolidayType.Public, false)]
        [InlineData("2023-07-11", HolidayType.CommonLocal, false)]
        [InlineData("2023-07-11", HolidayType.TypicalNonWorking, false)]
        [InlineData("2023-07-11", HolidayType.Public | HolidayType.CommonLocal, false)]
        [InlineData("2023-07-11", HolidayType.Public | HolidayType.TypicalNonWorking, false)]
        [InlineData("2023-07-11", HolidayType.CommonLocal | HolidayType.TypicalNonWorking, false)]
        [InlineData("2023-07-11", HolidayType.Public | HolidayType.CommonLocal | HolidayType.TypicalNonWorking, false)]
        [MemberData(nameof(GetIsHolidayData))]
        public void IsHoliday_ShouldReturnExpectedResult(DateTime inputDate, HolidayType holidayType, bool expectedResult)
        {
            // Arrange
            // No need for any arrange as the SwedenHolidayService class is static.

            // Act
            var result = SwedishHolidayService.IsHoliday(inputDate, holidayType);

            // Assert
            Assert.Equal(expectedResult, result);
        }

        public static IEnumerable<object[]> GetIsHolidayData()
        {
            yield return new object[] { new DateTime(DateTime.Now.Year, 1, 1), HolidayType.Public | HolidayType.CommonLocal, true };
            yield return new object[] { SwedishHolidayService.GetEasterSunday(DateTime.Now.Year), HolidayType.Public, true };
            yield return new object[] { SwedishHolidayService.GetEasterSunday(DateTime.Now.Year).AddDays(-1), HolidayType.CommonLocal, true };
            yield return new object[] { SwedishHolidayService.CalculateFathersDay(DateTime.Now.Year), HolidayType.TypicalNonWorking, true };
            yield return new object[] { new DateTime(DateTime.Now.Year, 7, 11), HolidayType.Public, false };
            yield return new object[] { new DateTime(DateTime.Now.Year, 7, 11), HolidayType.CommonLocal, false };
            yield return new object[] { new DateTime(DateTime.Now.Year, 7, 11), HolidayType.TypicalNonWorking, false };
            yield return new object[] { new DateTime(DateTime.Now.Year, 7, 11), HolidayType.Public | HolidayType.TypicalNonWorking, false };
            yield return new object[] { new DateTime(DateTime.Now.Year, 12, 24), HolidayType.TypicalNonWorking | HolidayType.CommonLocal, true };
        }

        [Theory]
        [InlineData(2013, "2013-03-31")]
        [InlineData(2014, "2014-04-20")]
        [InlineData(2015, "2015-04-05")]
        [InlineData(2016, "2016-03-27")]
        [InlineData(2023, "2023-04-09")]
        [InlineData(2024, "2024-03-31")]
        [InlineData(2025, "2025-04-20")]
        public void GetEasterSunday_ShouldReturnExpectedResult(int year, string expectedDate)
        {
            // Arrange
            var expectedDateTime = DateTime.Parse(expectedDate);

            // Act
            var result = SwedishHolidayService.GetEasterSunday(year);

            // Assert
            Assert.Equal(expectedDateTime, result);
        }

        [Theory]
        [InlineData(2013, "2013-06-21")]
        [InlineData(2014, "2014-06-20")]
        [InlineData(2015, "2015-06-19")]
        [InlineData(2016, "2016-06-24")]
        [InlineData(2017, "2017-06-23")]
        [InlineData(2018, "2018-06-22")]
        [InlineData(2019, "2019-06-21")]
        [InlineData(2023, "2023-06-23")]
        [InlineData(2024, "2024-06-21")]
        [InlineData(2025, "2025-06-20")]
        public void CalculateMidsummersEve_ShouldReturnExpectedResult(int year, string expectedDate)
        {
            // Arrange
            var expectedDateTime = DateTime.Parse(expectedDate);

            // Act
            var result = SwedishHolidayService.CalculateMidsummersEve(year);

            // Assert
            Assert.Equal(expectedDateTime, result);
        }


        [Theory]
        [InlineData(2013, "2013-11-01")]
        [InlineData(2014, "2014-10-31")]
        [InlineData(2015, "2015-10-30")]
        [InlineData(2016, "2016-11-04")]
        [InlineData(2017, "2017-11-03")]
        [InlineData(2018, "2018-11-02")]
        [InlineData(2019, "2019-11-01")]
        [InlineData(2023, "2023-11-03")]
        [InlineData(2024, "2024-11-01")]
        [InlineData(2025, "2025-10-31")]
        public void CalculateAllSaintsEve_ShouldReturnExpectedResult(int year, string expectedDate)
        {
            // Arrange
            var expectedDateTime = DateTime.Parse(expectedDate);

            // Act
            var result = SwedishHolidayService.CalculateAllSaintsEve(year);

            // Assert
            Assert.Equal(expectedDateTime, result);
        }

        [Theory]
        [InlineData(2013, "2013-11-10")]
        [InlineData(2014, "2014-11-09")]
        [InlineData(2015, "2015-11-08")]
        [InlineData(2016, "2016-11-13")]
        [InlineData(2017, "2017-11-12")]
        [InlineData(2018, "2018-11-11")]
        [InlineData(2019, "2019-11-10")]
        [InlineData(2023, "2023-11-12")]
        [InlineData(2024, "2024-11-10")]
        [InlineData(2025, "2025-11-09")]
        public void CalculateFathersDay_ReturnsCorrectDate(int year, string expected)
        {
            DateTime expectedDate = DateTime.Parse(expected);

            DateTime result = SwedishHolidayService.CalculateFathersDay(year);

            Assert.Equal(expectedDate, result);
        }

        [Theory]
        [InlineData(2013, "2013-05-26")]
        [InlineData(2014, "2014-05-25")]
        [InlineData(2015, "2015-05-31")]
        [InlineData(2016, "2016-05-29")]
        [InlineData(2017, "2017-05-28")]
        [InlineData(2018, "2018-05-27")]
        [InlineData(2019, "2019-05-26")]
        [InlineData(2023, "2023-05-28")]
        [InlineData(2024, "2024-05-26")]
        [InlineData(2025, "2025-05-25")]
        public void CalculateMothersDay_ReturnsCorrectDate(int year, string expected)
        {
            DateTime expectedDate = DateTime.Parse(expected);

            DateTime result = SwedishHolidayService.CalculateMothersDay(year);

            Assert.Equal(expectedDate, result);
        }

        [Theory]
        [InlineData(2013, 1, "2013-12-01")]
        [InlineData(2013, 2, "2013-12-08")]
        [InlineData(2013, 3, "2013-12-15")]
        [InlineData(2013, 4, "2013-12-22")]
        [InlineData(2014, 1, "2014-11-30")]
        [InlineData(2014, 2, "2014-12-07")]
        [InlineData(2014, 3, "2014-12-14")]
        [InlineData(2014, 4, "2014-12-21")]
        [InlineData(2015, 1, "2015-11-29")]
        [InlineData(2015, 2, "2015-12-06")]
        [InlineData(2015, 3, "2015-12-13")]
        [InlineData(2015, 4, "2015-12-20")]
        [InlineData(2016, 1, "2016-11-27")]
        [InlineData(2016, 2, "2016-12-04")]
        [InlineData(2016, 3, "2016-12-11")]
        [InlineData(2016, 4, "2016-12-18")]
        [InlineData(2017, 1, "2017-12-03")]
        [InlineData(2018, 1, "2018-12-02")]
        [InlineData(2023, 1, "2023-12-03")]
        [InlineData(2024, 1, "2024-12-01")]
        [InlineData(2025, 1, "2025-11-30")]
        [InlineData(2025, 2, "2025-12-07")]
        [InlineData(2025, 3, "2025-12-14")]
        [InlineData(2025, 4, "2025-12-21")]
        public void CalculateAdventSunday_ReturnsCorrectDate(int year, int adventNumber, string expected)
        {
            DateTime expectedDate = DateTime.Parse(expected);

            DateTime result = SwedishHolidayService.CalculateAdventSunday(year, adventNumber);

            Assert.Equal(expectedDate, result);
        }

        [Theory]
        [MemberData(nameof(GetSwedishPublicHolidayData))]
        public void GetSwedishPublicHolidaysAndTitle_ShouldReturnExpectedResult2(int year,
            Dictionary<DateTime, string> expectedHolidays)
        {
            // Arrange
            //var holidays = new SwedishPublicHolidayService();

            // Act
            var result = SwedishHolidayService.GetSwedishPublicHolidaysAndTitle(year);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedHolidays, result);
        }

        public static IEnumerable<object[]> GetSwedishPublicHolidayData()
        {
            yield return new object[] { 2013, new Dictionary<DateTime, string>
                {
                    { new DateTime(2013, 1, 1), "New Year's Day" },
                    { new DateTime(2013, 1, 6), "Epiphany" },
                    { new DateTime(2013, 5, 1), "May Day" },
                    { new DateTime(2013, 6, 6), "National Day of Sweden" },
                    { new DateTime(2013, 6, 22), "Midsummer's Day" },
                    { new DateTime(2013, 11, 2), "All Saints' Day" },
                    { new DateTime(2013, 12, 25), "Christmas Day" },
                    { new DateTime(2013, 12, 26), "Boxing Day" },
                    { new DateTime(2013, 3, 29), "Good Friday" },
                    { new DateTime(2013, 3, 31), "Easter Sunday" },
                    { new DateTime(2013, 4, 1), "Easter Monday" },
                    { new DateTime(2013, 5, 9), "Ascension Day" },
                    { new DateTime(2013, 5, 19), "Whit Sunday" }
                }};
            yield return new object[] { 2014, new Dictionary<DateTime, string>
                {
                    { new DateTime(2014, 1, 1), "New Year's Day" },
                    { new DateTime(2014, 1, 6), "Epiphany" },
                    { new DateTime(2014, 5, 1), "May Day" },
                    { new DateTime(2014, 6, 6), "National Day of Sweden" },
                    { new DateTime(2014, 6, 21), "Midsummer's Day" },
                    { new DateTime(2014, 11, 1), "All Saints' Day" },
                    { new DateTime(2014, 12, 25), "Christmas Day" },
                    { new DateTime(2014, 12, 26), "Boxing Day" },
                    { new DateTime(2014, 4, 18), "Good Friday" },
                    { new DateTime(2014, 4, 20), "Easter Sunday" },
                    { new DateTime(2014, 4, 21), "Easter Monday" },
                    { new DateTime(2014, 5, 29), "Ascension Day" },
                    { new DateTime(2014, 6, 8), "Whit Sunday" }
                }};
            yield return new object[] { 2015, new Dictionary<DateTime, string>
                {
                    { new DateTime(2015, 1, 1), "New Year's Day" },
                    { new DateTime(2015, 1, 6), "Epiphany" },
                    { new DateTime(2015, 5, 1), "May Day" },
                    { new DateTime(2015, 6, 6), "National Day of Sweden" },
                    { new DateTime(2015, 6, 20), "Midsummer's Day" },
                    { new DateTime(2015, 10, 31), "All Saints' Day" },
                    { new DateTime(2015, 12, 25), "Christmas Day" },
                    { new DateTime(2015, 12, 26), "Boxing Day" },
                    { new DateTime(2015, 4, 3), "Good Friday" },
                    { new DateTime(2015, 4, 5), "Easter Sunday" },
                    { new DateTime(2015, 4, 6), "Easter Monday" },
                    { new DateTime(2015, 5, 14), "Ascension Day" },
                    { new DateTime(2015, 5, 24), "Whit Sunday" }
                }};
        }


        [Theory]
        [MemberData(nameof(GetSwedishCommonLocalHolidaysAndTitleData))]
        public void GetSwedishCommonLocalHolidaysAndTitle_ReturnsExpectedHolidays(int year, Dictionary<DateTime, string> expectedHolidays)
        {
            var actualHolidays = SwedishHolidayService.GetSwedishCommonLocalHolidaysAndTitle(year);
            Assert.Equal(expectedHolidays, actualHolidays);
        }

        public static IEnumerable<object[]> GetSwedishCommonLocalHolidaysAndTitleData()
        {
            yield return new object[] { 2013, new Dictionary<DateTime, string>
                {
                    { new DateTime(2013, 1, 5), "Twelfth Night" },
                    { new DateTime(2013, 3, 30), "Holy Saturday" },
                    { new DateTime(2013, 4, 30), "Walpurgis Night" },
                    { new DateTime(2013, 5, 18), "Whit Saturday" },
                    { new DateTime(2013, 6, 21), "Midsummer's Eve" },
                    { new DateTime(2013, 11, 1), "All Saints' Eve" },
                    { new DateTime(2013, 12, 24), "Christmas Eve" },
                    { new DateTime(2013, 12, 31), "New Year's Eve" },
                }
            };
            yield return new object[] { 2014, new Dictionary<DateTime, string>
                {
                    { new DateTime(2014, 1, 5), "Twelfth Night" },
                    { new DateTime(2014, 4, 19), "Holy Saturday" },
                    { new DateTime(2014, 4, 30), "Walpurgis Night" },
                    { new DateTime(2014, 6, 7), "Whit Saturday" },
                    { new DateTime(2014, 6, 20), "Midsummer's Eve" },
                    { new DateTime(2014, 10, 31), "All Saints' Eve" },
                    { new DateTime(2014, 12, 24), "Christmas Eve" },
                    { new DateTime(2014, 12, 31), "New Year's Eve" },
                }
            };
            yield return new object[] { 2015, new Dictionary<DateTime, string>
                {
                    { new DateTime(2015, 1, 5), "Twelfth Night" },
                    { new DateTime(2015, 4, 4), "Holy Saturday" },
                    { new DateTime(2015, 4, 30), "Walpurgis Night" },
                    { new DateTime(2015, 5, 23), "Whit Saturday" },
                    { new DateTime(2015, 6, 19), "Midsummer's Eve" },
                    { new DateTime(2015, 10, 30), "All Saints' Eve" },
                    { new DateTime(2015, 12, 24), "Christmas Eve" },
                    { new DateTime(2015, 12, 31), "New Year's Eve" },
                }
            };
            yield return new object[] { 2016, new Dictionary<DateTime, string>
                {
                    { new DateTime(2016, 1, 5), "Twelfth Night" },
                    { new DateTime(2016, 3, 26), "Holy Saturday" },
                    { new DateTime(2016, 4, 30), "Walpurgis Night" },
                    { new DateTime(2016, 5, 14), "Whit Saturday" },
                    { new DateTime(2016, 6, 24), "Midsummer's Eve" },
                    { new DateTime(2016, 11, 4), "All Saints' Eve" },
                    { new DateTime(2016, 12, 24), "Christmas Eve" },
                    { new DateTime(2016, 12, 31), "New Year's Eve" },
                }
            };
            yield return new object[] { 2017, new Dictionary<DateTime, string>
                {
                    { new DateTime(2017, 1, 5), "Twelfth Night" },
                    { new DateTime(2017, 4, 15), "Holy Saturday" },
                    { new DateTime(2017, 4, 30), "Walpurgis Night" },
                    { new DateTime(2017, 6, 3), "Whit Saturday" },
                    { new DateTime(2017, 6, 23), "Midsummer's Eve" },
                    { new DateTime(2017, 11, 3), "All Saints' Eve" },
                    { new DateTime(2017, 12, 24), "Christmas Eve" },
                    { new DateTime(2017, 12, 31), "New Year's Eve" },
                }
            };
            yield return new object[] { 2018, new Dictionary<DateTime, string>
                {
                    { new DateTime(2018, 1, 5), "Twelfth Night" },
                    { new DateTime(2018, 3, 31), "Holy Saturday" },
                    { new DateTime(2018, 4, 30), "Walpurgis Night" },
                    { new DateTime(2018, 5, 19), "Whit Saturday" },
                    { new DateTime(2018, 6, 22), "Midsummer's Eve" },
                    { new DateTime(2018, 11, 2), "All Saints' Eve" },
                    { new DateTime(2018, 12, 24), "Christmas Eve" },
                    { new DateTime(2018, 12, 31), "New Year's Eve" },
                }
            };
            yield return new object[] { 2023, new Dictionary<DateTime, string>
                {
                    { new DateTime(2023, 1, 5), "Twelfth Night" },
                    { new DateTime(2023, 4, 8), "Holy Saturday" },
                    { new DateTime(2023, 4, 30), "Walpurgis Night" },
                    { new DateTime(2023, 5, 27), "Whit Saturday" },
                    { new DateTime(2023, 6, 23), "Midsummer's Eve" },
                    { new DateTime(2023, 11, 3), "All Saints' Eve" },
                    { new DateTime(2023, 12, 24), "Christmas Eve" },
                    { new DateTime(2023, 12, 31), "New Year's Eve" },
                }
            };
            yield return new object[] { 2024, new Dictionary<DateTime, string>
                {
                    { new DateTime(2024, 1, 5), "Twelfth Night" },
                    { new DateTime(2024, 3, 30), "Holy Saturday" },
                    { new DateTime(2024, 4, 30), "Walpurgis Night" },
                    { new DateTime(2024, 5, 18), "Whit Saturday" },
                    { new DateTime(2024, 6, 21), "Midsummer's Eve" },
                    { new DateTime(2024, 11, 1), "All Saints' Eve" },
                    { new DateTime(2024, 12, 24), "Christmas Eve" },
                    { new DateTime(2024, 12, 31), "New Year's Eve" },
                }
            };
            yield return new object[] { 2025, new Dictionary<DateTime, string>
                {
                    { new DateTime(2025, 1, 5), "Twelfth Night" },
                    { new DateTime(2025, 4, 19), "Holy Saturday" },
                    { new DateTime(2025, 4, 30), "Walpurgis Night" },
                    { new DateTime(2025, 6, 7), "Whit Saturday" },
                    { new DateTime(2025, 6, 20), "Midsummer's Eve" },
                    { new DateTime(2025, 10, 31), "All Saints' Eve" },
                    { new DateTime(2025, 12, 24), "Christmas Eve" },
                    { new DateTime(2025, 12, 31), "New Year's Eve" },
                }
            };
        }

        [Theory]
        [MemberData(nameof(GetHolidayData))]
        public void GetSwedishTypicalNonWorkingHolidaysAndTitle_ReturnsExpectedHolidays(int year, Dictionary<DateTime, string> expectedHolidays)
        {
            var actualHolidays = SwedishHolidayService.GetSwedishTypicalNonWorkingHolidaysAndTitle(year);
            Assert.Equal(expectedHolidays, actualHolidays);
        }

        public static IEnumerable<object[]> GetHolidayData()
        {
            yield return new object[] { 2013, new Dictionary<DateTime, string>
                {
                    { new DateTime(2013, 2, 14), "Valentine's Day" },
                    { new DateTime(2013, 5, 26), "Mother's Day" },
                    { new DateTime(2013, 11, 10), "Father's Day" },
                    { new DateTime(2013, 12, 1), "First Advent Sunday" },
                    { new DateTime(2013, 12, 8), "Second Advent Sunday" },
                    { new DateTime(2013, 12, 15), "Third Advent Sunday" },
                    { new DateTime(2013, 12, 22), "Fourth Advent Sunday" },
                }
            };
            yield return new object[] { 2014, new Dictionary<DateTime, string>
                {
                    { new DateTime(2014, 2, 14), "Valentine's Day" },
                    { new DateTime(2014, 5, 25), "Mother's Day" },
                    { new DateTime(2014, 11, 9), "Father's Day" },
                    { new DateTime(2014, 11, 30), "First Advent Sunday" },
                    { new DateTime(2014, 12, 7), "Second Advent Sunday" },
                    { new DateTime(2014, 12, 14), "Third Advent Sunday" },
                    { new DateTime(2014, 12, 21), "Fourth Advent Sunday" },
                }
            };
            yield return new object[] { 2015, new Dictionary<DateTime, string>
                {
                    { new DateTime(2015, 2, 14), "Valentine's Day" },
                    { new DateTime(2015, 5, 31), "Mother's Day" },
                    { new DateTime(2015, 11, 8), "Father's Day" },
                    { new DateTime(2015, 11, 29), "First Advent Sunday" },
                    { new DateTime(2015, 12, 6), "Second Advent Sunday" },
                    { new DateTime(2015, 12, 13), "Third Advent Sunday" },
                    { new DateTime(2015, 12, 20), "Fourth Advent Sunday" },
                }
            };
            yield return new object[] { 2016, new Dictionary<DateTime, string>
                {
                    { new DateTime(2016, 2, 14), "Valentine's Day" },
                    { new DateTime(2016, 5, 29), "Mother's Day" },
                    { new DateTime(2016, 11, 13), "Father's Day" },
                    { new DateTime(2016, 11, 27), "First Advent Sunday" },
                    { new DateTime(2016, 12, 4), "Second Advent Sunday" },
                    { new DateTime(2016, 12, 11), "Third Advent Sunday" },
                    { new DateTime(2016, 12, 18), "Fourth Advent Sunday" },
                }
            };
            yield return new object[] { 2017, new Dictionary<DateTime, string>
                {
                    { new DateTime(2017, 2, 14), "Valentine's Day" },
                    { new DateTime(2017, 5, 28), "Mother's Day" },
                    { new DateTime(2017, 11, 12), "Father's Day" },
                    { new DateTime(2017, 12, 3), "First Advent Sunday" },
                    { new DateTime(2017, 12, 10), "Second Advent Sunday" },
                    { new DateTime(2017, 12, 17), "Third Advent Sunday" },
                    { new DateTime(2017, 12, 24), "Fourth Advent Sunday" },
                }
            };
            yield return new object[] { 2018, new Dictionary<DateTime, string>
                {
                    { new DateTime(2018, 2, 14), "Valentine's Day" },
                    { new DateTime(2018, 5, 27), "Mother's Day" },
                    { new DateTime(2018, 11, 11), "Father's Day" },
                    { new DateTime(2018, 12, 2), "First Advent Sunday" },
                    { new DateTime(2018, 12, 9), "Second Advent Sunday" },
                    { new DateTime(2018, 12, 16), "Third Advent Sunday" },
                    { new DateTime(2018, 12, 23), "Fourth Advent Sunday" },
                }
            };
            yield return new object[] { 2019, new Dictionary<DateTime, string>
                {
                    { new DateTime(2019, 2, 14), "Valentine's Day" },
                    { new DateTime(2019, 5, 26), "Mother's Day" },
                    { new DateTime(2019, 11, 10), "Father's Day" },
                    { new DateTime(2019, 12, 1), "First Advent Sunday" },
                    { new DateTime(2019, 12, 8), "Second Advent Sunday" },
                    { new DateTime(2019, 12, 15), "Third Advent Sunday" },
                    { new DateTime(2019, 12, 22), "Fourth Advent Sunday" },
                }
            };
            yield return new object[] { 2020, new Dictionary<DateTime, string>
                {
                    { new DateTime(2020, 2, 14), "Valentine's Day" },
                    { new DateTime(2020, 5, 31), "Mother's Day" },
                    { new DateTime(2020, 11, 8), "Father's Day" },
                    { new DateTime(2020, 11, 29), "First Advent Sunday" },
                    { new DateTime(2020, 12, 6), "Second Advent Sunday" },
                    { new DateTime(2020, 12, 13), "Third Advent Sunday" },
                    { new DateTime(2020, 12, 20), "Fourth Advent Sunday" },
                }
            };
            yield return new object[] { 2021, new Dictionary<DateTime, string>
                {
                    { new DateTime(2021, 2, 14), "Valentine's Day" },
                    { new DateTime(2021, 5, 30), "Mother's Day" },
                    { new DateTime(2021, 11, 14), "Father's Day" },
                    { new DateTime(2021, 11, 28), "First Advent Sunday" },
                    { new DateTime(2021, 12, 5), "Second Advent Sunday" },
                    { new DateTime(2021, 12, 12), "Third Advent Sunday" },
                    { new DateTime(2021, 12, 19), "Fourth Advent Sunday" },
                }
            };
            yield return new object[] { 2022, new Dictionary<DateTime, string>
                {
                    { new DateTime(2022, 2, 14), "Valentine's Day" },
                    { new DateTime(2022, 5, 29), "Mother's Day" },
                    { new DateTime(2022, 11, 13), "Father's Day" },
                    { new DateTime(2022, 11, 27), "First Advent Sunday" },
                    { new DateTime(2022, 12, 4), "Second Advent Sunday" },
                    { new DateTime(2022, 12, 11), "Third Advent Sunday" },
                    { new DateTime(2022, 12, 18), "Fourth Advent Sunday" },
                }
            };
        }
    }
}
