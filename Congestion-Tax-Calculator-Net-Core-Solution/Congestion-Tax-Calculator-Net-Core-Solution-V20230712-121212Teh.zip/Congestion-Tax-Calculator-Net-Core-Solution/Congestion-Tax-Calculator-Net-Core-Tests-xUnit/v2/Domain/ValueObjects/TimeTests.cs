﻿using congestion.calculator.v2.Domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Domain.ValueObjects
{
    public class TimeTests
    {
        [Fact]
        public void Time_ConstructedWithTicks_ShouldHaveCorrectTime()
        {
            // Arrange
            long ticks = 1234567890;

            // Act
            var time = new Time(ticks);

            // Assert
            Assert.Equal(1, time.AsDateTime.Year);
            Assert.Equal(1, time.AsDateTime.Month);
            Assert.Equal(1, time.AsDateTime.Day);
            Assert.Equal(0, time.AsDateTime.Hour);
            Assert.Equal(2, time.AsDateTime.Minute);
            Assert.Equal(3, time.AsDateTime.Second);
            Assert.Equal(456, time.AsDateTime.Millisecond);
        }

        [Fact]
        public void Time_ConstructedWithHourMinuteSecondMillisecond_ShouldHaveCorrectTime()
        {
            // Arrange
            int hour = 10;
            int minute = 17;
            int second = 36;
            int millisecond = 789;

            // Act
            var time = new Time(hour, minute, second, millisecond);

            // Assert
            Assert.Equal(1, time.AsDateTime.Year);
            Assert.Equal(1, time.AsDateTime.Month);
            Assert.Equal(1, time.AsDateTime.Day);
            Assert.Equal(hour, time.AsDateTime.Hour);
            Assert.Equal(minute, time.AsDateTime.Minute);
            Assert.Equal(second, time.AsDateTime.Second);
            Assert.Equal(millisecond, time.AsDateTime.Millisecond);
        }

        [Fact]
        public void Time_ConstructedWithDateTime_ShouldHaveCorrectTimeUsingDateTimeConstructor()
        {
            // Arrange
            var dateTime = new DateTime(1, 1, 1, 10, 17, 36, 789);

            // Act
            var time = new Time(dateTime);

            // Assert
            Assert.Equal(dateTime, time.AsDateTime);
        }

        [Fact]
        public void Time_ParseExact_ShouldHaveCorrectTimeUsingStringConstructor()
        {
            // Arrange
            string timeString = "10:17:36.789";

            // Act
            var time = new Time(timeString);

            // Assert
            Assert.Equal(1, time.AsDateTime.Year);
            Assert.Equal(1, time.AsDateTime.Month);
            Assert.Equal(1, time.AsDateTime.Day);
            Assert.Equal(10, time.AsDateTime.Hour);
            Assert.Equal(17, time.AsDateTime.Minute);
            Assert.Equal(36, time.AsDateTime.Second);
            Assert.Equal(789, time.AsDateTime.Millisecond);
        }

        [Fact]
        public void Time_ParseExact_ShouldNotHaveCorrectTimeUsingWrongStringForConstructor()
        {
            // Arrange

            // Act
            Time time = null;

            // Assert
            Assert.Throws<FormatException>(() => time = new Time("25:18:36.789"));
            Assert.Throws<FormatException>(() => time = new Time("20:88:36.789"));
            Assert.Throws<FormatException>(() => time = new Time("20:18:76.789"));
            Assert.Throws<FormatException>(() => time = new Time("salam"));
            Assert.Null(time);
        }

        /*
         * Test of set accessor for AsDateTime property
        [Fact]
        public void Time_SetDateTimeWithInvalidHour_ShouldThrowArgumentOutOfRangeException()
        {
            // Arrange
            var time = new Time();
            var dateTime = new DateTime(1, 1, 1, 24, 0, 0);
            // Act & Assert
            Assert.Throws<ArgumentOutOfRangeException>(() => time.AsDateTime = dateTime);
        }

        [Fact]
        public void Time_SetDateTimeWithInvalidMinute_ShouldThrowArgumentOutOfRangeException()
        {
            // Arrange
            var time = new Time();
            var dateTime = new DateTime(1, 1, 1, 10, 60, 0);
            // Act & Assert
            Assert.Throws<ArgumentOutOfRangeException>(() => time.AsDateTime = dateTime);
        }

        [Fact]
        public void Time_SetDateTimeWithInvalidSecond_ShouldThrowArgumentOutOfRangeException()
        {
            // Arrange
            var time = new Time();
            var dateTime = new DateTime(1, 1, 1, 10, 17, 60);
            // Act & Assert
            Assert.Throws<ArgumentOutOfRangeException>(() => time.AsDateTime = dateTime);
        }

        */

        [Fact]
        public void Time_Equals_ShouldReturnTrueForSameInstance()
        {
            // Arrange
            var time = new Time(10, 17, 36, 789);

            // Act & Assert
            Assert.True(time.Equals(time));
        }

        [Fact]
        public void Time_Equals_ShouldReturnTrueForEqualObjects()
        {
            // Arrange
            var time1 = new Time(10, 17, 36, 789);
            var time2 = new Time(10, 17, 36, 789);

            // Act & Assert
            Assert.True(time1.Equals(time2));
        }

        [Fact]
        public void Time_Equals_ShouldReturnFalseForDifferentObjects()
        {
            // Arrange
            var time1 = new Time(10, 17, 36, 789);
            var time2 = new Time(10, 17, 36, 788);

            // Act & Assert
            Assert.False(time1.Equals(time2));
        }

        [Fact]
        public void Time_Equals_ShouldReturnFalseForNull()
        {
            // Arrange
            var time = new Time(10, 17, 36, 789);

            // Act & Assert
            Assert.False(time.Equals(null));
        }

        [Fact]
        public void Time_Equals_ShouldReturnFalseForDifferentType()
        {
            // Arrange
            var time = new Time(10, 17, 36, 789);
            var obj = new object();

            // Act & Assert
            Assert.False(time.Equals(obj));
        }

        [Fact]
        public void Time_GetHashCode_ShouldReturnSameValueForEqualObjects()
        {
            // Arrange
            var time1 = new Time(10, 17, 36, 789);
            var time2 = new Time(10, 17, 36, 789);

            // Act & Assert
            Assert.Equal(time1.GetHashCode(), time2.GetHashCode());
        }

        [Fact]
        public void Time_CompareTo_ShouldReturnPositiveValueForNull()
        {
            // Arrange
            var time1 = new Time(10, 17, 35, 789);
            Time time2 = null;

            // Act
            int result = time1.CompareTo(time2);

            // Assert
            Assert.True(result > 0);
        }

        [Fact]
        public void Time_CompareTo_ShouldReturnNegativeValueForLessThan()
        {
            // Arrange
            var time1 = new Time(10, 17, 35, 789);
            var time2 = new Time(10, 17, 36, 0);

            // Act
            int result = time1.CompareTo(time2);

            // Assert
            Assert.True(result < 0);
        }

        [Fact]
        public void Time_CompareTo_ShouldReturnZeroForEqualObjects()
        {
            // Arrange
            var time1 = new Time(10, 17, 36, 789);
            var time2 = new Time(10, 17, 36, 789);

            // Act
            int result = time1.CompareTo(time2);

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void Time_CompareTo_ShouldReturnPositiveValueForGreaterThan()
        {
            // Arrange
            var time1 = new Time(10, 17, 37, 0);
            var time2 = new Time(10, 17, 36, 789);

            // Act
            int result = time1.CompareTo(time2);

            // Assert
            Assert.True(result > 0);
        }

        [Fact]
        public void Time_OperatorEqual_ShouldReturnTrueForSameObject()
        {
            // Arrange
            var time1 = new Time(10, 17, 36, 789);

            // Act
            bool result = time1 == time1;

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void Time_OperatorEqual_ShouldReturnFalseForNull()
        {
            // Arrange
            var time1 = new Time(10, 17, 36, 789);

            // Act
            bool result1 = time1 == null;
            bool result2 = null == time1;

            // Assert
            Assert.False(result1);
            Assert.False(result2);
        }

        [Fact]
        public void Time_OperatorEqual_ShouldReturnTrueForEqualObjects()
        {
            // Arrange
            var time1 = new Time(10, 17, 36, 789);
            var time2 = new Time(10, 17, 36, 789);

            // Act
            bool result = time1 == time2;

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void Time_OperatorEqual_ShouldReturnFalseForDifferentObjects()
        {
            // Arrange
            var time1 = new Time(10, 17, 36, 789);
            var time2 = new Time(10, 17, 36, 788);

            // Act
            bool result = time1 == time2;

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void Time_OperatorNotEqual_ShouldReturnTrueForDifferentObjects()
        {
            // Arrange
            var time1 = new Time(10, 17, 36, 789);
            var time2 = new Time(10, 17, 36, 788);

            // Act
            bool result = time1 != time2;

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void Time_OperatorLessThan_ShouldReturnTrueForLessThan()
        {
            // Arrange
            var time1 = new Time(10, 17, 35, 789);
            var time2 = new Time(10, 17, 36, 0);

            // Act
            bool result = time1 < time2;

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void Time_OperatorLessThanOrEqual_ShouldReturnTrueForLessThan()
        {
            // Arrange
            var time1 = new Time(10, 17, 35, 789);
            var time2 = new Time(10, 17, 36, 0);

            // Act
            bool result = time1 <= time2;

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void Time_OperatorGreaterThan_ShouldReturnTrueForGreaterThan()
        {
            // Arrange
            var time1 = new Time(10, 17, 37, 0);
            var time2 = new Time(10, 17, 36, 789);

            // Act
            bool result = time1 > time2;

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void Time_ComparisonOperatorsWithTimeObject_ShouldReturnCorrectResult()
        {
            // Arrange
            var time1 = new Time(10, 17, 36, 789);
            var time2 = new Time(10, 17, 36, 789);
            var time3 = new Time(10, 17, 36, 788);

            // Act
            var result1 = time1 > time2;
            var result2 = time1 >= time2;
            var result3 = time1 == time2;
            var result4 = time1 != time2;
            var result5 = time1 < time2;
            var result6 = time1 <= time2;
            var result7 = time1 > time3;
            var result8 = time1 >= time3;
            var result9 = time1 == time3;
            var result10 = time1 != time3;
            var result11 = time1 < time3;
            var result12 = time1 <= time3;

            // Assert
            Assert.False(result1);
            Assert.True(result2);
            Assert.True(result3);
            Assert.False(result4);
            Assert.False(result5);
            Assert.True(result6);
            Assert.True(result7);
            Assert.True(result8);
            Assert.False(result9);
            Assert.True(result10);
            Assert.False(result11);
            Assert.False(result12);
        }

        [Fact]
        public void Time_ComparisonOperatorsWithDateTimeObject_ShouldReturnCorrectResult()
        {
            // Arrange
            var time1 = new Time(10, 17, 36, 789);
            Time time2 = null;
            var date1 = new DateTime(2023, 7, 7, 10, 17, 36, 789);
            var date2 = new DateTime(2023, 7, 7, 10, 17, 36, 788);

            // Act
            var result1 = time1 > date1;
            var result2 = time1 >= date1;
            var result3 = time1 == date1;
            var result4 = time1 != date1;
            var result5 = time1 < date1;
            var result6 = time1 <= date1;
            var result7 = time1 > date2;
            var result8 = time1 >= date2;
            var result9 = time1 == date2;
            var result10 = time1 != date2;
            var result11 = time1 < date2;
            var result12 = time1 <= date2;
            var result13 = time2 < date2;
            var result14 = time2 <= date2;
            var result15 = time2 == date2;
            var result16 = time2 < time1;
            var result17 = time2 <= time1;
            var result18 = time2 == time1;

            // Assert
            Assert.False(result1);
            Assert.True(result2);
            Assert.True(result3);
            Assert.False(result4);
            Assert.False(result5);
            Assert.True(result6);
            Assert.True(result7);
            Assert.True(result8);
            Assert.False(result9);
            Assert.True(result10);
            Assert.False(result11);
            Assert.False(result12);
            Assert.True(result13);
            Assert.True(result14);
            Assert.False(result15);
            Assert.True(result16);
            Assert.True(result17);
            Assert.False(result18);
        }

        [Fact]
        public void ToString_ReturnsCorrectStringRepresentation()
        {
            // Arrange
            var time = new Time(9);

            // Act
            var result = time.ToString();

            // Assert
            Assert.Equal("09", result);
        }

        [Fact]
        public void ToString_ReturnsCorrectStringRepresentationWithMinute()
        {
            // Arrange
            var time = new Time(9, 30);

            // Act
            var result = time.ToString();

            // Assert
            Assert.Equal("09:30", result);
        }

        [Fact]
        public void ToString_ReturnsCorrectStringRepresentationWithSeconds()
        {
            // Arrange
            var time = new Time(9, 30, 45);

            // Act
            var result = time.ToString();

            // Assert
            Assert.Equal("09:30:45", result);
        }

        [Fact]
        public void ToString_ReturnsCorrectStringRepresentationWithMilliseconds()
        {
            // Arrange
            var time = new Time(9, 30, 45, 500);

            // Act
            var result = time.ToString();

            // Assert
            Assert.Equal("09:30:45.500", result);
        }

        [Fact]
        public void ToString_ReturnsCorrectStringRepresentationWithLeadingZero()
        {
            // Arrange
            var time = new Time(1, 2);

            // Act
            var result = time.ToString();

            // Assert
            Assert.Equal("01:02", result);
        }

        [Fact]
        public void ToString_ReturnsCorrectStringRepresentationWithLeadingZeroAndSeconds()
        {
            // Arrange
            var time = new Time(1, 2, 3);

            // Act
            var result = time.ToString();

            // Assert
            Assert.Equal("01:02:03", result);
        }

        [Fact]
        public void ToString_ReturnsCorrectStringRepresentationWithLeadingZeroAndMilliseconds()
        {
            // Arrange
            var time = new Time(1, 2, 3, 4);

            // Act
            var result = time.ToString();

            // Assert
            Assert.Equal("01:02:03.004", result);
        }
    }
}