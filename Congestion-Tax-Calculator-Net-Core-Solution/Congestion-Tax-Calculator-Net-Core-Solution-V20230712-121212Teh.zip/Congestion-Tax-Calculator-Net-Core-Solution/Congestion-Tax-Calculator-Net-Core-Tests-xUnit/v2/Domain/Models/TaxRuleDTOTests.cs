﻿using System;
using System.Collections.Generic;
using System.Text;
using congestion.calculator.v2.Domain.Models;
using congestion.calculator.v2.Domain.ValueObjects;
using Xunit;

namespace congestion.calculator.NetCore.Tests.xUnit.v2.Domain.Models
{


    public class TaxRuleDTOTests
    {
        [Fact]
        public void ToString_ReturnsCorrectStringRepresentation()
        {
            // Arrange
            var taxRuleDTO = new TaxRuleDTO
            {
                City = "New York",
                StarTime = new Time(9, 0),
                EndTime = new Time(17, 0),
                Fee = 10
            };

            // Act
            var result = taxRuleDTO.ToString();

            // Assert
            Assert.Equal("City: New York, StartTime: 09, EndTime: 17, Fee: 10", result);
        }

        [Fact]
        public void Equals_SameObject_ReturnsTrue()
        {
            // Arrange
            var taxRuleDTO = new TaxRuleDTO
            {
                City = "New York",
                StarTime = new Time(9, 0),
                EndTime = new Time(17, 0),
                Fee = 10
            };

            // Act
            var result = taxRuleDTO.Equals(taxRuleDTO);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void Equals_NullObject_ReturnsFalse()
        {
            // Arrange
            var taxRuleDTO = new TaxRuleDTO
            {
                City = "New York",
                StarTime = new Time(9, 0),
                EndTime = new Time(17, 0),
                Fee = 10
            };

            // Act
            var result = taxRuleDTO.Equals(null);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void Equals_DifferentType_ReturnsFalse()
        {
            // Arrange
            var taxRuleDTO = new TaxRuleDTO
            {
                City = "New York",
                StarTime = new Time(9, 0),
                EndTime = new Time(17, 0),
                Fee = 10
            };

            // Act
            var result = taxRuleDTO.Equals("not a TaxRuleDTO");

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void Equals_DifferentCity_ReturnsFalse()
        {
            // Arrange
            var taxRuleDTO1 = new TaxRuleDTO
            {
                City = "New York",
                StarTime = new Time(9, 0),
                EndTime = new Time(17, 0),
                Fee = 10
            };

            var taxRuleDTO2 = new TaxRuleDTO
            {
                City = "Boston",
                StarTime = new Time(9, 0),
                EndTime = new Time(17, 0),
                Fee = 10
            };

            // Act
            var result = taxRuleDTO1.Equals(taxRuleDTO2);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void Equals_DifferentStartTime_ReturnsFalse()
        {
            // Arrange
            var taxRuleDTO1 = new TaxRuleDTO
            {
                City = "New York",
                StarTime = new Time(9, 0),
                EndTime = new Time(17, 0),
                Fee = 10
            };

            var taxRuleDTO2 = new TaxRuleDTO
            {
                City = "New York",
                StarTime = new Time(10, 0),
                EndTime = new Time(17, 0),
                Fee = 10
            };

            // Act
            var result = taxRuleDTO1.Equals(taxRuleDTO2);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void Equals_DifferentEndTime_ReturnsFalse()
        {
            // Arrange
            var taxRuleDTO1 = new TaxRuleDTO
            {
                City = "New York",
                StarTime = new Time(9, 0),
                EndTime = new Time(17, 0),
                Fee = 10
            };

            var taxRuleDTO2 = new TaxRuleDTO
            {
                City = "New York",
                StarTime = new Time(9, 0),
                EndTime = new Time(18, 0),
                Fee = 10
            };

            // Act
            var result = taxRuleDTO1.Equals(taxRuleDTO2);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void Equals_DifferentFee_ReturnsFalse()
        {
            // Arrange
            var taxRuleDTO1 = new TaxRuleDTO
            {
                City = "New York",
                StarTime = new Time(9, 0),
                EndTime = new Time(17, 0),
                Fee = 10
            };

            var taxRuleDTO2 = new TaxRuleDTO
            {
                City = "New York",
                StarTime = new Time(9, 0),
                EndTime = new Time(17, 0),
                Fee = 20
            };

            // Act
            var result = taxRuleDTO1.Equals(taxRuleDTO2);

            // Assert
            Assert.False(result);
        }
    }
}
